package akio1.test;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.StringJoiner;

import com.github.javaparser.ParseException;
import com.github.javaparser.ParserConfiguration;
import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;
import com.github.javaparser.symbolsolver.JavaSymbolSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.CombinedTypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.JarTypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.JavaParserTypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.ReflectionTypeSolver;
import com.google.common.base.Strings;

public class Sample {

	public static final String ORIGIN_DIR = "C:\\pleiades\\workspace\\backlog\\src";

	public static final List<String> SEARCH_DIR_LIST = Arrays.asList(
			"C:\\pleiades\\workspace\\backlog\\src\\jp\\co\\jsol\\backlog\\controller",
			"C:\\pleiades\\workspace\\backlog\\src\\jp\\co\\jsol\\backlog\\service");

	public static FileWriter fw;

	public static void main(String[] args) throws IOException, ParseException {

		fw = new FileWriter("sample.txt");

		setParserConfig();

		for (String dir : SEARCH_DIR_LIST) {
			File projectDir = new File(dir);
			listMethodCalls(projectDir);
		}

	}

	private static void setParserConfig() throws IOException {
		CombinedTypeSolver typeSolver = new CombinedTypeSolver(new ReflectionTypeSolver(false)
				,new JavaParserTypeSolver(new File(ORIGIN_DIR))
				,new JarTypeSolver(new File("C:\\Users\\User\\.m2\\repository\\org\\apache\\commons\\commons-lang3\\3.3.2\\commons-lang3-3.3.2.jar"))
				,new JarTypeSolver(new File("C:\\Users\\User\\.m2\\repository\\com\\nulab-inc\\backlog4j\\2.3.3\\backlog4j-2.3.3.jar")));

		ParserConfiguration config = new ParserConfiguration();
		config.setSymbolResolver(new JavaSymbolSolver(typeSolver));
		StaticJavaParser.setConfiguration(config);
	}

	public static void listMethodCalls(File projectDir) throws ParseException {

		new DirExplorer((level, path, file) -> path.endsWith(".java"), (level, path, file) -> {
			System.out.println(path);
			System.out.println(Strings.repeat("=", path.length()));

			try {
				new VoidVisitorAdapter<Object>() {
					@Override
					public void visit(MethodDeclaration n, Object arg) {
						List<NameExpr> nes = n.findAll(NameExpr.class);

						nes.stream().filter(ne -> needsData(ne))
								.forEach(ne -> {
									print(n, ne);

								});

						super.visit(n, arg);
					}

					private boolean needsData(NameExpr ne) {

						String type = ne.calculateResolvedType().describe();

						// java固有のメソッドの呼び出しは評価に利用しない
						if (type.contains("java.")) {
//							return false;
						}

						//						if(type.contains("Service")) {
						//							return true;
						//						}

						List<String> primitiveTypeList = Arrays.asList("int", "long", "boolean");

						if (primitiveTypeList.contains(type)) {
//							return false;
						}

						return true;

					}

					private void print(MethodDeclaration n, NameExpr ne) {

						Node parent = ne.getParentNode().orElse(null);

						if (!(parent instanceof MethodCallExpr)) {
							return;
						}

						StringJoiner sj = new StringJoiner("\t");
						sj.add(path);
						sj.add(n.getNameAsString());
						sj.add(ne.getBegin().get().toString());
						sj.add(ne.calculateResolvedType().describe());

						sj.add(((MethodCallExpr) parent).getNameAsString());

//						System.out.println(sj.toString());
						try {
							fw.write(sj.toString() + "\r\n");
						} catch (IOException e) {
							// TODO 自動生成された catch ブロック
							e.printStackTrace();
						}
					}

				}.visit(StaticJavaParser.parse(file), null);
				System.out.println(); // empty line
			} catch (IOException e) {
				new RuntimeException(e);
			}
		}).explore(projectDir);
	}

}
