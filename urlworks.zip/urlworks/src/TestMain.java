import entity.Entity;
import logic.AbstractUrlReplaceLogic;
import logic.UrlReplaceSampleContentLogic;
import logic.UrlReplaceSampleRelationUrlLogic;

/** テストドライバ */
public class TestMain {

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static void main(String[] args) {

		AbstractUrlReplaceLogic[] logics
		 = {new UrlReplaceSampleRelationUrlLogic(), new UrlReplaceSampleContentLogic()};

		for (AbstractUrlReplaceLogic<Entity> logic : logics) {
			logic.execute();
		}

	}
}


