package entity;

public interface Entity {

}
