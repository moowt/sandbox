package entity;

/** 関連URLテーブルを想定したサンプルEntityクラス. */
public class SampleRelationUrl implements Entity {

	/** コンテンツID */
	private int contentId;
	/** 連番 */
	private int seq;
	/** URL */
	private String url;

	public SampleRelationUrl(int contentId, int seq, String url) {
		this.contentId = contentId;
		this.seq = seq;
		this.url = url;
	}

	public int getContentId() {
		return contentId;
	}

	public void setContentId(int contentId) {
		this.contentId = contentId;
	}

	public int getSeq() {
		return seq;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}



}
