package entity;

import java.time.LocalDate;

/** コンテンツを想定したサンプルEntityクラス. */
public class SampleContent implements Entity {

	/** コンテンツID */
	private int contentId;

	/** タイトル */
	private String title;

	/** タイトル */
	private String body;

	/** 補足情報 */
	private String supplement;

	/** 承認日 */
	private LocalDate approvalDate;

	public SampleContent(int contentId, String title, String body, String supplement, LocalDate approvalDate) {
		super();
		this.contentId = contentId;
		this.title = title;
		this.body = body;
		this.supplement = supplement;
		this.approvalDate = approvalDate;
	}

	public int getContentId() {
		return contentId;
	}

	public void setContentId(int contentId) {
		this.contentId = contentId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getSupplement() {
		return supplement;
	}

	public void setSupplement(String supplement) {
		this.supplement = supplement;
	}

	public LocalDate getApprovalDate() {
		return approvalDate;
	}

	public void setApprovalDate(LocalDate approvalDate) {
		this.approvalDate = approvalDate;
	}



}
