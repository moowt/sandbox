package entity;

/**
 * 各テーブル・カラム毎のURLを保持するEntityクラス.
 * @author User
 *
 */
public class URLWork {

	/** テーブル名 */
	private String table;
	/** カラム名 */
	private String column;
	/** 主キー */
	private String primaryKey;
	/** 連番 */
	private int seq;
	/** URL */
	private String url;

	public URLWork(String table, String column,String primaryKey, int seq, String url) {
		this.table = table;
		this.column = column;
		this.primaryKey = primaryKey;
		this.seq = seq;
		this.url = url;
	}

	public String getTable() {
		return table;
	}

	public void setTable(String table) {
		this.table = table;
	}

	public String getColumn() {
		return column;
	}

	public void setColumn(String column) {
		this.column = column;
	}


	public String getPrimaryKey() {
		return primaryKey;
	}

	public void setPrimaryKey(String primaryKey) {
		this.primaryKey = primaryKey;
	}

	public int getSeq() {
		return seq;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	@Override
	public String toString() {
		return "URLWork [table=" + table + ", column=" + column + ", primaryKey=" + primaryKey + ", seq=" + seq
				+ ", url=" + url + "]";
	}



}
