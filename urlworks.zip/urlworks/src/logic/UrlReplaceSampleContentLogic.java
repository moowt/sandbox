package logic;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import entity.SampleContent;

public class UrlReplaceSampleContentLogic extends AbstractUrlReplaceLogic<SampleContent> {

	@Override
	protected List<SampleContent> select() {
		List<SampleContent> list = new ArrayList<>();
		list.add(new SampleContent(1, "コンテンツの例", "これは https://ja.wikipedia.org/wiki/だよ\r\nhttp://twitter.com/home",
				"参考としてこちらを閲覧下さい：https://www.amazon.co.jp/ref=nav_logo", LocalDate.now()));
		list.add(new SampleContent(2, "URLなし例", "本文テスト", null, LocalDate.now()));

		return list;
	}

	@Override
	protected String getPrimaryKey(SampleContent t) {
		return Integer.toString(t.getContentId());
	}

}
