package logic;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import entity.Entity;
import entity.URLWork;

/**
 * URL置換処理に対する基底クラス。
 * 各コンテンツへのデータアクセスやデータモデルに関わる処理は個別のロジックに実装して下さい。
 * @author User
 * @param <T> Entityクラス
 */
public abstract class AbstractUrlReplaceLogic<T extends Entity> {

	protected static final String URL_REGEX = "\\b(https?|Notes)://[-a-zA-Z0-9+&@#/%?=~_|!:,.;]*[-a-zA-Z0-9+&@#/%=~_|]";


	/**
	 * エンティティのデータを取得。各テーブルへのアクセス
	 * @return 取得したエンティティのリスト
	 */
	protected abstract List<T> select();

	protected abstract String getPrimaryKey(T t);

	public final int execute() {

		// 実際には1000件ごとの取得など工夫が必要
		List<T> entityList = select();

		if (entityList.isEmpty()) {
			return 0;
		}
		// データ取得元のクラス取得
		Class<?> clazz = entityList.get(0).getClass();

		List<Field> fields = filterStringMethod(clazz);

		List<URLWork> resultList = new ArrayList<>();

		// レコード毎、フィールド毎にURLを抽出し、URLWorkテーブルに挿入
		for (T t : entityList) {

			String primaryKey = getPrimaryKey(t);

			for (Field field : fields) {

				try {
					// フィールドの値を取得
					String value = (String) field.get(t);

					if(value == null) {
						continue;
					}

					// ホントはここでWorkテーブルにINSERT
					resultList.addAll(convertToURLWorkList(createUrlList(value.replaceAll("\n", " ")), clazz.getSimpleName(), field.getName(),
							primaryKey));
//					System.out.println(value);
				} catch (IllegalArgumentException e) {
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				}

			}
		}
		// 結果出力
		resultList.forEach(System.out::println);

		return resultList.size();

	}

	/**
	 * 型が文字列であるようなフィールドのみ抽出する
	 * @param clazz 抽出対象のクラス
	 * @return 型が文字列であるようなフィールドのリスト
	 */
	private List<Field> filterStringMethod(Class<?> clazz) {

		List<Field> filteredFields = new ArrayList<>();

		for (Field field : clazz.getDeclaredFields()) {
			Class<?> t = field.getType();

			if (t == String.class) {
				// リフレクションでフィールドの値を取得するため、ここでアクセス可能に変更
				field.setAccessible(true);
				filteredFields.add(field);
			}
		}

		return filteredFields;
	}

	private List<String> createUrlList(String value) {

		// 入力値なしの場合は空のリストを返却
		if (value == null) {
			return new ArrayList<>();
		}

		Pattern p = Pattern.compile(URL_REGEX);
		Matcher m1 = p.matcher(value);

		// URLに合致するものが無い場合は空のリストを返却
		if (!m1.find()) {
			return new ArrayList<>();
		}

		List<String> urlList = new ArrayList<>();

		// URLにマッチする分だけループしてURLリストを返却
		do {
			urlList.add(m1.group());
		} while (m1.find());

		return urlList;

	}

	/**
	 * URLWork用のEntityに変換
	 * @param urlList
	 * @param className
	 * @param fieldName
	 * @param primaryKey
	 * @return
	 */
	private List<URLWork> convertToURLWorkList(List<String> urlList, String className, String fieldName,
			String primaryKey) {

		List<URLWork> urlWorkList = new ArrayList<>();

		int index = 1;
		for (String url : urlList) {
			urlWorkList.add(new URLWork(className, fieldName, primaryKey, index++, url));
		}

		return urlWorkList;
	}


}