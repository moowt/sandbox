package logic;

import java.util.ArrayList;
import java.util.List;

import entity.SampleRelationUrl;

public class UrlReplaceSampleRelationUrlLogic extends AbstractUrlReplaceLogic<SampleRelationUrl> {

	@Override
	protected List<SampleRelationUrl> select() {
		List<SampleRelationUrl> list = new ArrayList<>();
		list.add(new SampleRelationUrl(1, 1, "https://qiita.com/Fendo181/items/a934e4f94021115efb2e"));
		list.add(new SampleRelationUrl(3, 1,
				"https://sites.google.com/view/musica-moderna-orchestra/%E5%9B%A3%E5%93%A1%E5%8B%9F%E9%9B%86"));
		list.add(new SampleRelationUrl(3, 2, "https://paiza.jp/career/challenges/397/retry"));
		list.add(new SampleRelationUrl(3, 3, "http://www.google.com/"));
		list.add(new SampleRelationUrl(4, 1, " https://www.google.com/"));
		list.add(new SampleRelationUrl(5, 1, "GCPのURLはこちら→https://cloud.google.com/"));
		list.add(new SampleRelationUrl(5, 2, "参考情報だけでURL書いてないパターン"));
		list.add(new SampleRelationUrl(6, 1, "https://ja.wikipedia.org/wiki/, http://twitter.com/home"));
		return list;
	}

	@Override
	protected String getPrimaryKey(SampleRelationUrl t) {
		return t.getContentId() + "-" + t.getSeq();
	}

}
