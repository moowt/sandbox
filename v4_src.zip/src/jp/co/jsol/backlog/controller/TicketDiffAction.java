package jp.co.jsol.backlog.controller;

import java.util.List;

import jp.co.jsol.backlog.common.PropertyUtils;
import jp.co.jsol.backlog.model.ProjectInfo;
import jp.co.jsol.backlog.model.Ticket;
import jp.co.jsol.backlog.service.TicketDiffService;

public class TicketDiffAction extends BaseAction {


	@Override
	protected boolean isValid(String... args) {
		if (args == null || args.length != 1) {
			println("[ERROR]第二引数以降は不要です。");
			println("[ERROR]取得元・比較先プロジェクトを変更する場合はプロパティファイルを修正してください。");
			return false;
		}

		return true;
	}

	@Override
	protected void callService(String... args) {

		final String INPUT_PROJECT = PropertyUtils.getProperty("diff.project.input");
		final String COMPARE_PROJECT = PropertyUtils.getProperty("diff.project.compare");

		TicketDiffService service = new TicketDiffService(ProjectInfo.of(INPUT_PROJECT), ProjectInfo.of(COMPARE_PROJECT));
		List<Ticket> ticketList = service.getUnvotedTickets();

		if (ticketList.isEmpty()) {
			println("[INFO]比較先プロジェクトに未起票のチケットは存在しません。");
			return;
		}

		println("[INFO]未起票のチケット:" + ticketList.size() + "件");

		for (Ticket task : ticketList) {
			println(String.join(" ", task.getTicketId(), task.getSummary(), "[" + task.getStatus() + "]"));
		}

	}

}
