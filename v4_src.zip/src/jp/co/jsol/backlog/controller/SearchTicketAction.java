package jp.co.jsol.backlog.controller;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import jp.co.jsol.backlog.model.IssueSearchCondition.ParentChildType;
import jp.co.jsol.backlog.model.ProjectInfo;
import jp.co.jsol.backlog.model.Ticket;
import jp.co.jsol.backlog.service.SearchTicketService;

/**
 * 検索コマンドに対するアクションクラス。
 * @author Akio Yamamoto
 *
 */
public class SearchTicketAction extends BaseAction {


	@Override
	protected void init(String... args) {
		List<String> argsList = Arrays.asList(args);

		if (argsList.indexOf("-kw") != -1) {
			println("[INFO]キーワード検索を実行します。");
		}

		if (argsList.indexOf("-p") != -1) {
			println("[INFO]親子関係を設定して検索を実行します。");
		}

	}

	@Override
	protected boolean isValid(String... args) {

		if (args == null || args.length < 2) {
			println("[ERROR]入力形式が異なります。]" + Arrays.toString(args));
			return false;
		}

		String[] pjArray = args[1].split(",");

		for (String pjKey : pjArray) {
			try {
				ProjectInfo.of(pjKey);
			} catch (IllegalArgumentException e) {
				println(e.getMessage());
				return false;
			}

		}

		// キーワード検索に対するチェック
		List<String> argsList = Arrays.asList(args);
		int kwIndex = argsList.indexOf("-kw");

		if (kwIndex != -1 && kwIndex + 1 >= args.length) {
			println("[ERROR]-kw の後にキーワードをカンマ区切りで入力して下さい。:" + Arrays.toString(args));
			return false;
		}

		// 親子関係の入力値に対するチェック
		int pIndex = argsList.indexOf("-p");
		if (pIndex != -1 && pIndex + 1 >= args.length) {
			println("[ERROR]-p の後は以下のいずれかを入力して下さい[All,NotChild,Child,NotChildNotParent,Parent]:"
					+ Arrays.toString(args));
			return false;
		}

		if (pIndex != -1 && ParentChildType.getFromType(args[pIndex + 1]) == null) {
			println("[ERROR]-p の後は以下のいずれかを入力して下さい[All,NotChild,Child,NotChildNotParent,Parent]:"
					+ Arrays.toString(args));
			return false;
		}

		return true;
	}

	@Override
	protected void callService(String... args) {

		SearchTicketService service = new SearchTicketService();
		List<ProjectInfo> pjInfoList = Arrays.stream(args[1].split(","))
				.map(pjs -> ProjectInfo.of(pjs))
				.collect(Collectors.toList());

		List<String> argsList = Arrays.asList(args);

		// -pが含まれる場合は、親課題のみ
		int pIndex = argsList.indexOf("-p");
		ParentChildType pcType = (pIndex != -1) ? ParentChildType.getFromType(args[pIndex + 1]) : ParentChildType.All;

		int kwIndex = argsList.indexOf("-kw");
		String keyWords = (kwIndex != -1) ? args[kwIndex + 1].replaceAll(",", " ") : "";

		// 結果出力
		List<Ticket> resultTickets = service.doSearch(pjInfoList, pcType, keyWords);

		println("[INFO]検索結果：" + resultTickets.size() + "件");
		resultTickets.forEach(t -> println(t.toString()));

	}

}
