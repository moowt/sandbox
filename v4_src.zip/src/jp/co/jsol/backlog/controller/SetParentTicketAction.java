package jp.co.jsol.backlog.controller;

import java.util.Arrays;
import java.util.List;

import jp.co.jsol.backlog.model.ProjectInfo;
import jp.co.jsol.backlog.service.SetParentTicketService;

public class SetParentTicketAction extends BaseAction {


	@Override
	protected void init(String... args) {
		List<String> argsList = Arrays.asList(args);

		if (argsList.indexOf("close") == 2) {
			println("[INFO]親課題設定時に、ステータスが完了に更新されます。");
		}

	}

	@Override
	protected boolean isValid(String... args) {

		if (args == null || args.length < 4) {
			println("[ERROR]入力形式が異なります。]" + Arrays.toString(args));
			return false;
		}

		// 親課題の形式チェック
		String parentPj = args[1].split("-")[0];

		try {
			ProjectInfo.of(parentPj);
		} catch (Exception e) {
			println(e.getMessage());
			return false;
		}

		// 子課題の形式チェック
		List<String> argsList = Arrays.asList(args);
		int cIndex = argsList.indexOf("-c");

		if (cIndex < 0 || cIndex + 1 >= args.length) {
			println("[ERROR]-cの後に子課題(カンマ区切り)を入力して下さい。" + Arrays.toString(args));
			return false;
		}

		for (int i = cIndex + 1; i < args.length; i++) {
			String childPj = args[i].split("-")[0];

			if(!parentPj.equals(childPj)) {
				println("[ERROR]親課題と子課題のプロジェクトが一致しません。:" + childPj);
				return false;
			}
		}

		return true;
	}

	@Override
	protected void callService(String... args) {

		SetParentTicketService service = new SetParentTicketService();
		List<String> argsList = Arrays.asList(args);

		String parentKeyId = argsList.get(1);
		boolean isSetClosed = argsList.indexOf("close") == 2;

		List<String> childList = Arrays.asList(argsList.get(argsList.size()-1).split(","));

		List<String> messages = service.set(parentKeyId, childList, isSetClosed);
		println("対象件数:"+ childList +"件");
		messages.forEach(m -> println(m));

	}

}
