package jp.co.jsol.backlog.controller;

import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;

import jp.co.jsol.backlog.service.AlertAnalyzeService;
import jp.co.jsol.backlog.service.DailyAlertAnalyzeService;
import jp.co.jsol.backlog.service.MonthlyAlertAnalyzeService;
import jp.co.jsol.backlog.service.WeeklyAlertAnalyzeService;

public class AlertAnalyzeAction extends BaseAction {

	@Override
	protected boolean isValid(String... args) {
		if (args.length <= 1) {
			println("[ERROR] -daily, -weekly, -monthlyのいずれかを指定して下さい。");
			return false;
		}

		String mode = args[1];

		switch (mode) {
		case "-daily":
			return validateDaily(args);
		case "-weekly":
			return validateWeekly(args);
		case "-monthly":
			return validateMonthly(args);
		default:
			println("[ERROR] -daily, -weekly, -monthlyのいずれかを指定して下さい。:" + mode);
			return false;
		}
	}

	private boolean validateDaily(String[] args) {

		if (args.length == 2) {
			return true;
		}

		if(args.length == 3 && pushComment(args)) {
			return true;
		}

		String dateStr = getDateStr(args);

		try {
			LocalDate.parse(dateStr, DateTimeFormatter.ofPattern("uuuuMMdd").withResolverStyle(ResolverStyle.STRICT));
		} catch (DateTimeParseException e) {
			println("[ERROR] 日付形式はyyyymmddとして下さい。:" + args[2]);
			return false;
		}

		return true;
	}

	private boolean validateWeekly(String[] args) {

		if (args.length == 2) {
			return true;
		}

		if(args.length == 3 && pushComment(args)) {
			return true;
		}

		try {
			String dateStr = getDateStr(args);
			String[] period = dateStr.split("-");

			//fromのvalidation
			LocalDate.parse(period[0], DateTimeFormatter.ofPattern("uuuuMMdd").withResolverStyle(ResolverStyle.STRICT));
			//toのvalidation
			LocalDate.parse(period[1], DateTimeFormatter.ofPattern("uuuuMMdd").withResolverStyle(ResolverStyle.STRICT));

		} catch (RuntimeException e) {
			println("[ERROR] 日付形式はyyyymmdd-yyyymmddとして下さい。:" + args[2]);
			return false;
		}

		return true;
	}

	private boolean validateMonthly(String[] args) {
		if (args.length == 2) {
			return true;
		}

		if(args.length == 3 && pushComment(args)) {
			return true;
		}

		try {
			String dateStr = getDateStr(args);
			String[] period = dateStr.split("-");

			//fromのvalidation
			YearMonth.parse(period[0], DateTimeFormatter.ofPattern("uuuuMM").withResolverStyle(ResolverStyle.STRICT));
			//toのvalidation
			YearMonth.parse(period[1], DateTimeFormatter.ofPattern("uuuuMM").withResolverStyle(ResolverStyle.STRICT));

		} catch (RuntimeException e) {
			println("[ERROR] 日付形式はyyyymm-yyyymmとして下さい。:" + args[2]);
			return false;
		}

		return true;
	}



	@Override
	protected void callService(String... args) {
		String mode = args[1];

		AlertAnalyzeService service = null;
		String period = getDateStr(args);

		switch (mode) {
		case "-daily":
			service = new DailyAlertAnalyzeService(period);
			break;
		case "-weekly":
			service = new WeeklyAlertAnalyzeService(period);
			break;
		case "-monthly":
			service = new MonthlyAlertAnalyzeService(period);
			break;
		default:
			break;
		}

		service.execute(pushComment(args));
	}

	private boolean pushComment(String... args) {
		return args[args.length - 1].equals("-c");
	}


	private String getDateStr(String[] args) {

		if(args.length == 2) {
			return null;
		}

		if(args[2].startsWith("-c")) {
			return null;
		}

		return args[2];

	}
}
