package jp.co.jsol.backlog.model;

import org.apache.commons.lang3.StringUtils;

import jp.co.jsol.backlog.common.PropertyUtils;

/**
 * Backlogの1プロジェクトの情報を持つmodel.
 * @author Akio Yamamoto
 *
 */
public class ProjectInfo {

	/** 接続するAPI情報 */
	private ApiInfo apiInfo;

	/** プロジェクトID */
	private String projectId;

	/** プロジェクトの接頭辞. diffやcpコマンドに利用する. */
	private String prefix;

	public ProjectInfo(ApiInfo apiInfo, String projectId, String prefix) {
		this.apiInfo = apiInfo;
		this.projectId = projectId;
		this.prefix = prefix;
	}


	public static ProjectInfo of(String spaceId, String projectId) {

		if(StringUtils.isEmpty(spaceId)) {
			throw new IllegalArgumentException("【ERROR】スペースIDが空です.");
		}
		if(StringUtils.isEmpty(projectId)) {
			throw new IllegalArgumentException("【ERROR】プロジェクトIDが空です.");
		}

		String key = "pjinfo." + projectId.toLowerCase() + ".spaceId";
		String propValue = PropertyUtils.getProperty(key);

		if(!spaceId.equals(propValue)) {
			throw new IllegalArgumentException("入力されたプロジェクトIDが不正です.:" + projectId);
		}

		ApiInfo apiInfo = ApiInfo.of(spaceId);
		String prefix = PropertyUtils.getProperty("pjinfo." + projectId.toLowerCase() +".prefix", projectId);
		return new ProjectInfo(apiInfo, projectId, prefix);

	}

	/**
	 * プロジェクトIDを基にしたstaticファクトリ.
	 * [注意]スペース間で同一のプロジェクトIDのものが存在しないことを前提とする.
	 * @param projectId プロジェクトID
	 * @return プロジェクト情報
	 */
	public static ProjectInfo of(String projectId) {
		if(StringUtils.isEmpty(projectId)) {
			throw new IllegalArgumentException("【ERROR】プロジェクトIDが空です.");
		}

		String key = "pjinfo." + projectId.toLowerCase() + ".spaceid";
		String propValue = PropertyUtils.getProperty(key);

		if(StringUtils.isEmpty(propValue)) {
			throw new IllegalArgumentException("【ERROR】該当のプロジェクトに紐づくスペースIDがプロパティに定義されていません.:" + propValue);
		}

		ApiInfo apiInfo = ApiInfo.of(propValue);
		String prefix = PropertyUtils.getProperty("pjinfo." + projectId.toLowerCase() +".prefix", projectId);

		return new ProjectInfo(apiInfo, projectId, prefix);
	}


	/**
	 * チケット番号を返却する(ex:TGIF-300)
	 * @param no 該当プロジェクトのチケットの連番
	 * @return チケット番号
	 */
	public String getTicketNo(int no) {
		return this.projectId + "-" + no;
	}

	/**
	 * 引数の連番に紐づくチケットのURLを返却する
	 * @param no 該当プロジェクトのチケットの連番
	 * @return チケットのURL
	 */
	public String getTicketUrl(int no) {
		return apiInfo.getUrl() + "view/" + getTicketNo(no);
	}

	public ApiInfo getApiInfo() {
		return apiInfo;
	}

	public void setApiInfo(ApiInfo apiInfo) {
		this.apiInfo = apiInfo;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getPrefix() {
		return prefix;
	}

	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}

	@Override
	public String toString() {
		return "ProjectInfo [apiInfo=" + apiInfo + ", projectId=" + projectId + ", prefix=" + prefix + "]";
	}

}
