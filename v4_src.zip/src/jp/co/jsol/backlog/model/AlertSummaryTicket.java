package jp.co.jsol.backlog.model;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.Map;
import java.util.TreeMap;

public class AlertSummaryTicket extends Ticket {

	private Map<LocalDate, Integer> occuredCntMap = new TreeMap<>();

	public Map<LocalDate, Integer> getOccuredCntMap() {
		return occuredCntMap;
	}

	public void addCnt(LocalDate date) {
		if (!occuredCntMap.containsKey(date)) {
			occuredCntMap.put(date, 1);
			return;
		}

		occuredCntMap.replace(date, occuredCntMap.get(date) + 1);
	}

	public int getOccuredCnt() {
		return occuredCntMap.values().stream().mapToInt(cnt -> cnt).sum();
	}

	public int getOccuredCnt(YearMonth ym) {

		return occuredCntMap.entrySet().stream()
			.filter(e -> e.getKey().getYear() == ym.getYear() && e.getKey().getMonth()
			.equals(ym.getMonth()))
			.mapToInt(Map.Entry::getValue)
			.sum();
	}

}
