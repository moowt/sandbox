package jp.co.jsol.backlog.model;

/** コンソール表示用の課題を表すモデル */
public class Ticket {

	/** issueId(API側の主キー) */
	private long issueId;
	/** タスクキー */
	private String ticketId;
	/** タイトル */
	private String summary;
	/** ステータス */
	private String status;

	public long getIssueId() {
		return issueId;
	}

	public void setIssueId(long issueId) {
		this.issueId = issueId;
	}

	public String getTicketId() {
		return ticketId;
	}

	public void setTicketId(String ticket) {
		this.ticketId = ticket;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getKeyId() {
		return Integer.parseInt(ticketId.split("-")[1]);
	}

	public ProjectInfo getPjInfo() {
		return ProjectInfo.of(ticketId.split("-")[0]);
	}

	@Override
	public String toString() {
		return String.join(" ", getTicketId(), getSummary(), "[" + getStatus() +
				"]");
	}

}
