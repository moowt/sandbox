package jp.co.jsol.backlog;

import jp.co.jsol.backlog.model.ProjectInfo;
import jp.co.jsol.backlog.repository.BacklogRepository;

public class TestMain {
	public static void main(String[] args) {
		BacklogRepository rep = BacklogRepository.of(ProjectInfo.of("AKITASK"));

		rep.addComment("AKITASK-1994", "テスト");

	}
}
