package jp.co.jsol.backlog.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.StringJoiner;

import jp.co.jsol.backlog.common.PrintUtils;
import jp.co.jsol.backlog.common.PropertyUtils;
import jp.co.jsol.backlog.comparator.AlertSummaryTicketComparator;
import jp.co.jsol.backlog.model.AlertSummaryTicket;
import jp.co.jsol.backlog.model.IssueSearchCondition;

public class WeeklyAlertAnalyzeService extends AlertAnalyzeService {

	private LocalDate since;
	private LocalDate until;

	public WeeklyAlertAnalyzeService(String period) {
		if (period == null) {
			// 先週の月曜日をsince, 日曜日をuntilに設定
			LocalDate now = LocalDate.now();
			int adjustDay = now.getDayOfWeek().getValue() - 1;

			since = now.minusWeeks(1).minusDays(adjustDay);
			until = since.plusDays(6);

			PrintUtils.println("[INFO]" + since + " - " + until + "の期間で集計します。");
			return;
		}

		// 期間が設定されている場合
		String[] periodArray = period.split("-");
		since = LocalDate.parse(periodArray[0], DateTimeFormatter.BASIC_ISO_DATE);
		until = LocalDate.parse(periodArray[1], DateTimeFormatter.BASIC_ISO_DATE);

		PrintUtils.println("[INFO]" + since + " - " + until + "の期間で集計します。");
	}

	@Override
	protected List<AlertSummaryTicket> createReport() {

		// 期間内に発生したアラートをすべて取得
		IssueSearchCondition cond = new IssueSearchCondition();
		cond.setCreatedSince(since.toString());
		cond.setCreatedUntil(until.toString());

		List<AlertSummaryTicket> summaryList = createSummaryInfo(cond);
		summaryList.sort(new AlertSummaryTicketComparator());

		return summaryList;
	}

	@Override
	protected String createFileName() {
		// TODO 自動生成されたメソッド・スタブ
		return "AlertSummary_weekly_" + since.format(DateTimeFormatter.ofPattern("uuuuMMdd")) + "-"
				+ until.format(DateTimeFormatter.ofPattern("uuuuMMdd"))
				+ ".tsv";
	}

	@Override
	protected String createFileHeader() {

		StringJoiner periodSj = new StringJoiner("\t");
		// sinceからuntilまで1日ずつ
		for (LocalDate date = since; date.compareTo(until) <= 0; date = date.plusDays(1)) {
			periodSj.add(date.toString());
		}
		periodSj.add("合計");

		return FILE_HEADER_BASE.replace("期間埋め込み", periodSj.toString());
	}

	@Override
	protected String createFileBody(List<AlertSummaryTicket> reportData) {

		StringJoiner sj = new StringJoiner("\n");

		for (AlertSummaryTicket ast : reportData) {

			StringJoiner periodSj = new StringJoiner("\t");

			for (LocalDate date = since; date.compareTo(until) <= 0; date = date.plusDays(1)) {
				periodSj.add(writeDayCnt(ast, date));
			}

			String totalCnt = Integer.toString(ast.getOccuredCnt());

			sj.add(String.join("\t", ast.getTicketId(), ast.getSummary(), ast.getStatus(),
					periodSj.toString(), totalCnt));

		}

		return sj.toString();

	}

	private String writeDayCnt(AlertSummaryTicket ast, LocalDate date) {
		Integer cnt = ast.getOccuredCntMap().get(date);
		return cnt == null ? "" : Integer.toString(cnt);
	}

	@Override
	protected String createCommentTitle() {
		return since + " - " + until + "のアラート発生状況(日別)";
	}

	@Override
	protected String createCommentTicketId() {
		return PropertyUtils.getProperty("alertaz.ticketid.output.weekly");
	}

}
