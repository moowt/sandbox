package jp.co.jsol.backlog.service;

import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.StringJoiner;

import jp.co.jsol.backlog.common.PrintUtils;
import jp.co.jsol.backlog.common.PropertyUtils;
import jp.co.jsol.backlog.comparator.AlertSummaryTicketComparator;
import jp.co.jsol.backlog.model.AlertSummaryTicket;
import jp.co.jsol.backlog.model.IssueSearchCondition;

public class MonthlyAlertAnalyzeService extends AlertAnalyzeService {

	private YearMonth since;
	private YearMonth until;

	public MonthlyAlertAnalyzeService(String period) {
		if (period == null) {
			LocalDate now = LocalDate.now();
			int periodYearMonths = Integer.parseInt(PropertyUtils.getProperty("alertaz.monthly.months", "3"));

			since = YearMonth.of(now.minusMonths(periodYearMonths).getYear(),
					now.minusMonths(periodYearMonths).getMonth());
			until = YearMonth.of(now.minusMonths(1).getYear(), now.minusMonths(1).getMonth());

			PrintUtils.println("[INFO]" + since + " - " + until + "の期間で集計します。");
			return;
		}

		// 期間が設定されている場合
		String[] periodArray = period.split("-");
		since = YearMonth.parse(periodArray[0], DateTimeFormatter.ofPattern("uuuuMM"));
		until = YearMonth.parse(periodArray[1], DateTimeFormatter.ofPattern("uuuuMM"));

		PrintUtils.println("[INFO]" + since + " - " + until + "の期間で集計します。");
	}

	@Override
	protected List<AlertSummaryTicket> createReport() {

		// 期間内に発生したアラートをすべて取得
		IssueSearchCondition cond = new IssueSearchCondition();

		cond.setCreatedSince(since.atDay(1).toString());
		cond.setCreatedUntil(until.atEndOfMonth().toString());

		List<AlertSummaryTicket> summaryList = createSummaryInfo(cond);
		summaryList.sort(new AlertSummaryTicketComparator());

		return summaryList;
	}

	@Override
	protected String createFileName() {
		return "AlertSummary_monthly_" + since.format(DateTimeFormatter.ofPattern("uuuuMM")) + "-"
				+ until.format(DateTimeFormatter.ofPattern("uuuuMM"))
				+ ".tsv";
	}

	@Override
	protected String createFileHeader() {

		StringJoiner periodSj = new StringJoiner("\t");
		// sinceからuntilまで1日ずつ
		for (YearMonth ym = since; ym.compareTo(until) <= 0; ym = ym.plusMonths(1)) {
			periodSj.add(ym.toString());
		}
		periodSj.add("合計");

		return FILE_HEADER_BASE.replace("期間埋め込み", periodSj.toString());
	}

	@Override
	protected String createFileBody(List<AlertSummaryTicket> reportData) {

		StringJoiner sj = new StringJoiner("\n");

		for (AlertSummaryTicket ast : reportData) {

			StringJoiner periodSj = new StringJoiner("\t");

			for (YearMonth ym = since; ym.compareTo(until) <= 0; ym = ym.plusMonths(1)) {
				periodSj.add(writeDayCnt(ast, ym));
			}

			String totalCnt = Integer.toString(ast.getOccuredCnt());

			sj.add(String.join("\t", ast.getTicketId(), ast.getSummary(), ast.getStatus(),
					periodSj.toString(), totalCnt));

		}

		return sj.toString();
	}

	private String writeDayCnt(AlertSummaryTicket ast, YearMonth ym) {
		int cnt = ast.getOccuredCnt(ym);
		return cnt == 0 ? "" : Integer.toString(cnt);
	}

	@Override
	protected String createCommentTitle() {
		return since + " - " + until + "のアラート発生状況(月別)";
	}

	@Override
	protected String createCommentTicketId() {
		return PropertyUtils.getProperty("alertaz.ticketid.output.monthly");
	}


}
