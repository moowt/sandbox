package jp.co.jsol.backlog.service;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import org.apache.commons.lang3.StringUtils;

import com.nulabinc.backlog4j.Issue;

import jp.co.jsol.backlog.common.TicketUtils;
import jp.co.jsol.backlog.model.ProjectInfo;
import jp.co.jsol.backlog.model.Ticket;
import jp.co.jsol.backlog.repository.BacklogRepository;

/**
 * BackLogのキーIDをもとにチケット情報を取得するサービス.
 * @author Akio Yamamoto
 *
 */
public class GetTicketForKeyService {

	/**
	 * キーに紐づくチケット情報を取得する
	 * @param key キーID(プロジェクト名+連番)
	 * @param isOpen チケットをブラウザで開く場合はtrue
	 * @return チケット情報。ただし、該当のチケットが存在しない場合はnullを返却する。
	 */
	public Ticket searchForKey(String key, boolean isOpen) throws IllegalArgumentException {

		if(StringUtils.isEmpty(key)) {
			throw new IllegalArgumentException("[ERROR]キーの入力がありません。");
		}

		String[] splitedKey = key.split("-");

		if (splitedKey.length != 2 || !StringUtils.isNumeric(splitedKey[1])) {
			throw new IllegalArgumentException("[ERROR]入力されたキーは不正です。:" + key);
		}

		ProjectInfo pjInfo = ProjectInfo.of(splitedKey[0]);

		if (pjInfo == null) {
			throw new IllegalArgumentException("[ERROR]入力されたプロジェクトは存在しません。:" + splitedKey[0]);
		}

		BacklogRepository repository = BacklogRepository.of(pjInfo);
		Issue issue = repository.selectIssueByKeyId(Integer.parseInt(splitedKey[1]));

		if(issue == null) {
			return null;
		}

		Ticket resultTicket = TicketUtils.convertTicketFromIssue(issue);

		if(isOpen) {
			browse(pjInfo, resultTicket.getKeyId());
		}

		return resultTicket;
	}

	private void browse(ProjectInfo pjInfo, int keyId) {
		Desktop desktop = Desktop.getDesktop();
		String website = pjInfo.getTicketUrl(keyId);
		try {
			desktop.browse(new URI(website));
		} catch (IOException | URISyntaxException e) {
			throw new RuntimeException("[ERROR]該当チケットを開こうとしましたが、失敗しました。;",e);
		}
	}
}
