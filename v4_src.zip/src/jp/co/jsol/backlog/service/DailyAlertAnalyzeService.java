package jp.co.jsol.backlog.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.StringJoiner;

import jp.co.jsol.backlog.common.PrintUtils;
import jp.co.jsol.backlog.common.PropertyUtils;
import jp.co.jsol.backlog.comparator.AlertSummaryTicketComparator;
import jp.co.jsol.backlog.model.AlertSummaryTicket;
import jp.co.jsol.backlog.model.IssueSearchCondition;

public class DailyAlertAnalyzeService extends AlertAnalyzeService {

	private LocalDate execDate;

	public DailyAlertAnalyzeService(String execDate) {
		this.execDate = getExecDate(execDate);

		PrintUtils.println("[INFO]" + this.execDate + "の日付で集計します。");
	}

	@Override
	protected List<AlertSummaryTicket> createReport() {

		String execDateStr = convertLocalDateToString(execDate);

		// 期間内に発生したアラートをすべて取得
		IssueSearchCondition cond = new IssueSearchCondition();
		cond.setCreatedSince(execDateStr);
		cond.setCreatedUntil(execDateStr);

		List<AlertSummaryTicket> summaryList = createSummaryInfo(cond);
		summaryList.sort(new AlertSummaryTicketComparator());

		return summaryList;
	}

	@Override
	protected String createFileName() {
		return "AlertSummary_daily_" + execDate.format(DateTimeFormatter.ofPattern("uuuuMMdd"))
				+ ".tsv";
	}

	@Override
	protected String createFileHeader() {
		return FILE_HEADER_BASE.replace("期間埋め込み", execDate.toString());
	}

	@Override
	protected String createFileBody(List<AlertSummaryTicket> reportData) {

		StringJoiner sj = new StringJoiner("\n");

		for (AlertSummaryTicket ast : reportData) {
			sj.add(String.join("\t", ast.getTicketId(), ast.getSummary(), ast.getStatus(),
					Integer.toString(ast.getOccuredCnt())));
		}

		return sj.toString();
	}

	private LocalDate getExecDate(String periodStr) {

		if (periodStr == null) {
			return LocalDate.now();
		}

		return LocalDate.parse(periodStr, DateTimeFormatter.ofPattern("uuuuMMdd"));
	}

	@Override
	protected String createCommentTitle() {
		return execDate + "のアラート発生状況";
	}

	@Override
	protected String createCommentTicketId() {
		return PropertyUtils.getProperty("alertaz.ticketid.output.daily");
	}

}
