package jp.co.jsol.backlog.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringJoiner;
import java.util.TreeSet;

import org.apache.commons.lang3.StringUtils;

import com.nulabinc.backlog4j.Issue;

import jp.co.jsol.backlog.common.PropertyUtils;
import jp.co.jsol.backlog.common.TicketUtils;
import jp.co.jsol.backlog.model.ProjectInfo;
import jp.co.jsol.backlog.model.Ticket;
import jp.co.jsol.backlog.repository.BacklogRepository;

/**
 * Backlogプロジェクトのチケットを別プロジェクトに転記するサービス.
 * @author Akio Yamamoto
 *
 */
public class PostingTicketService {

	private static final String OUTPUT_PROJECT_NAME = PropertyUtils.getProperty("cp.project.output");

	private static final String PROGRESS_REGEX = "cp.issue.progress.";

	private ProjectInfo outputPjInfo = ProjectInfo.of(OUTPUT_PROJECT_NAME);

	private BacklogRepository outputRepository = BacklogRepository.of(outputPjInfo);

	private GetTicketForKeyService getTicketService = new GetTicketForKeyService();


	/**
	 * チケットの転記を行う。転記されたチケットは、課題タイプ、タイトル、本文、優先度が以下の通り設定される。
	 * 課題タイプ：backlogapi.propertiesに記載されたタイプ。存在しない場合は「その他」
	 * タイトル：元チケットの番号およびタイトル
	 * 本文：元チケットのURL
	 * 優先度：中
	 * 入力されたタスクキーIDが存在しない場合は、転記は行わない。
	 * @param ticketIds タスクキーIDの一覧(例:TGIF-123)
	 * @params hasTasks タスク一覧のチェックボックスを追加するか。
	 * @return 転記の結果を表すメッセージのリスト
	 */
	public List<String> post(List<String> ticketIds, boolean hasTasks) {

		if (ticketIds == null || ticketIds.isEmpty()) {
			throw new IllegalArgumentException("[ERROR]入力値が存在しません。");
		}
		List<String> resultList = new ArrayList<>();

		for (String taskKeyId : ticketIds) {
			//１つずつ転記実施
			resultList.add(post(taskKeyId, hasTasks));
		}

		return resultList;
	}

	private String post(String ticketId, boolean hasTasks) {

		// 取得元からチケット情報を抽出する
		Ticket task;

		try {
			task = getTicketService.searchForKey(ticketId, false);
		} catch (IllegalArgumentException e) {
			return e.getMessage();
		}

		if (task == null) {
			return "[ERROR]該当のチケットは存在しません。:" + ticketId;
		}

		// 出力先に該当チケットが既に存在しているか確認
		if (isAlreadyExist(task)) {
			return "[ERROR]転記しようとしているチケットは既に存在します。:" + ticketId;
		}

		// 転記
		String issueType = PropertyUtils.getProperty("cp.issue.type", "その他");
		String description = String.join("", "元チケット", TicketUtils.CRLF(),
				task.getPjInfo().getTicketUrl(task.getKeyId()), TicketUtils.CRLF());

		if(hasTasks) {
			description += addTasks();
		}

		String outputKeyId = outputRepository.insertIssue(issueType, createSummary(task), description);

		return String.join("", "[INFO]元チケット ",ticketId," を ", outputKeyId," に転記しました。");
	}

	private String addTasks() {

		Map<String, String> taskPropMap = PropertyUtils.getStartMatchProperties(PROGRESS_REGEX);


		StringJoiner sj = new StringJoiner(StringUtils.LF, StringUtils.LF, "");
		sj.add("＜タスク一覧＞" + StringUtils.LF);

		Set<String> sortedKeys = new TreeSet<String>(taskPropMap.keySet());
		sortedKeys.forEach(k -> sj.add("* [ ] " + taskPropMap.get(k)));



		return sj.toString();
	}

	private String createSummary(Ticket t) {
		ProjectInfo pjInfo = t.getPjInfo();
		String head = PropertyUtils.getProperty("cp.issue.prefix", t.getPjInfo().getProjectId());
		return String.join("", head, pjInfo.getPrefix(), "-", Integer.toString(t.getKeyId()), " ", t.getSummary());
	}

	private boolean isAlreadyExist(Ticket t) {
		List<Issue> chekingIssues = outputRepository.selectIssuesByKeyword(t.getSummary());

		if (chekingIssues.isEmpty()) {
			return false;
		}

		for (Issue issue : chekingIssues) {
			int seq = TicketUtils.pollOutKeyId(t.getPjInfo().getPrefix() ,issue.getSummary());

			if (seq == t.getKeyId()) {
				return true;
			}
		}

		return false;
	}

}
