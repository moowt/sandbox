package jp.co.jsol.backlog.service;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.apache.commons.lang3.StringUtils;

import com.nulabinc.backlog4j.Issue;

import jp.co.jsol.backlog.common.PrintUtils;
import jp.co.jsol.backlog.common.PropertyUtils;
import jp.co.jsol.backlog.common.TicketUtils;
import jp.co.jsol.backlog.model.AlertSummaryTicket;
import jp.co.jsol.backlog.model.IssueSearchCondition;
import jp.co.jsol.backlog.model.ProjectInfo;
import jp.co.jsol.backlog.repository.BacklogRepository;

public abstract class AlertAnalyzeService {

	protected static final String INPUT_PROJECT_NAME = PropertyUtils.getProperty("alertaz.project.input");

	protected ProjectInfo inputPjInfo = ProjectInfo.of(INPUT_PROJECT_NAME);

	protected BacklogRepository inputRepository = BacklogRepository.of(inputPjInfo);

	protected static final String OUTPUT_PROJECT_NAME = PropertyUtils.getProperty("alertaz.project.output");

	protected ProjectInfo outputPjInfo = ProjectInfo.of(OUTPUT_PROJECT_NAME);

	protected BacklogRepository outputRepository = BacklogRepository.of(outputPjInfo);



	protected static final String FILE_HEADER_BASE = String.join("\t", "チケットID", "チケット名", "ステータス", "期間埋め込み");


	public void execute(boolean pushCommentFlag) {
		List<AlertSummaryTicket> reportData = createReport();
		createFile(reportData);

		if(pushCommentFlag) {
			pushComment();
		}
	}


	/** レポート用のデータ取得 */
	protected abstract List<AlertSummaryTicket>  createReport();

	/** 出力するファイルのファイル名を設定 */
	protected abstract String createFileName();

	/** 出力するファイルのヘッダを設定 */
	protected abstract String createFileHeader();

	/** 出力するファイルのボディ部を設定 */
	protected abstract String createFileBody(List<AlertSummaryTicket> reportData);

	protected abstract String createCommentTitle();

	protected abstract String createCommentTicketId();


	/** Backlogへのコメント */
	protected void pushComment() {
		StringJoiner sj = new StringJoiner("\n");
		sj.add("◆ " + createCommentTitle()).add("");

		String header = createFileHeader();
		List<AlertSummaryTicket> astList = createReport();

		if (astList.isEmpty()) {
			sj.add("アラートは発生していません。").add("");
		} else {

			sj.add(header.replaceAll("\t", " | "))
					.add(createBorder(header))
					.add(createFileBody(createReport()).replaceAll("\t", " | "))
					.add("");
		}

		// 宛先
		sj.add(PropertyUtils.getProperty("alertaz.notifieduser"));

		outputRepository.addComment(createCommentTicketId(), sj.toString());

		PrintUtils.println("[INFO]" +createCommentTicketId() +"に集計結果をコメントしました。");
	}


	private String createBorder(String header) {
		int tabCnt = StringUtils.countMatches(header, "\t");
		List<String> borderList = IntStream.range(0, tabCnt).mapToObj(i -> "---").collect(Collectors.toList());

		return String.join(" | ", borderList);
	}

	private void createFile(List<AlertSummaryTicket> reportData) {

		String fileName = createFileName();

		Path path = Paths.get(fileName);

		try (BufferedWriter bw = Files.newBufferedWriter(path, StandardCharsets.UTF_8);
				PrintWriter pw = new PrintWriter(bw)) {

			pw.println(createFileHeader());
			pw.println(createFileBody(reportData));

		} catch (IOException e) {
			PrintUtils.println("[ERROR]ファイル書き込みエラー" + e.getMessage());
			e.printStackTrace();
		}

		PrintUtils.println("[INFO]正常にファイル出力完了しました。:" + fileName);
	}

	protected String convertLocalDateToString(final LocalDate date) {
		return date.format(DateTimeFormatter.ofPattern("uuuu-MM-dd"));
	}

	protected LocalDate convertStringToLocalDate(final String date) {
		return LocalDate.parse(date, DateTimeFormatter.BASIC_ISO_DATE);
	}


	protected LocalDate convertDateToLocalDate(final java.util.Date date) {
		return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
	}

	protected List<AlertSummaryTicket> createSummaryInfo(IssueSearchCondition cond) {

		List<Issue> alertList = inputRepository.selectIssues(cond);

		// 取得した課題から、親課題のみを抽出する
		Map<Long, AlertSummaryTicket> summariesMap = initializeSummaryMap(alertList);

		// カウント
		for (Issue issue : alertList) {

			long putId = isChildIssue(issue) ? issue.getParentIssueId() : issue.getId();
			summariesMap.get(putId).addCnt(convertDateToLocalDate(issue.getCreated()));
		}

		return new ArrayList<>(summariesMap.values());
	}

	private Map<Long, AlertSummaryTicket> initializeSummaryMap(List<Issue> alertList) {
		Map<Long, AlertSummaryTicket> summariesMap = new HashMap<>();

		for (Issue issue : alertList) {

			// mapに要素が既に存在するかをチェックする。
			// 取得した課題が子課題である場合は親課題、それ以外(親課題、単独)は自身の課題のissueIdをチェック。
			long checkIssueId = isChildIssue(issue) ? issue.getParentIssueId() : issue.getId();

			if (summariesMap.containsKey(checkIssueId)) {
				continue;
			}

			Issue putObj = issue;
			if (isChildIssue(issue)) {
				// 子課題の場合は親課題の情報が必要になる
				putObj = inputRepository.selectIssueByIssueId(issue.getParentIssueId());
			}

			AlertSummaryTicket asTicket = (AlertSummaryTicket) TicketUtils
					.setTicketFromIssue(new AlertSummaryTicket(), putObj);
			summariesMap.put(asTicket.getIssueId(), asTicket);

		}

		return summariesMap;
	}

	private boolean isChildIssue(Issue issue) {
		return issue.getParentIssueId() != 0;
	}

}
