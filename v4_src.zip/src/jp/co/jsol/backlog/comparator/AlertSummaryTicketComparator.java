package jp.co.jsol.backlog.comparator;

import java.util.Comparator;

import jp.co.jsol.backlog.model.AlertSummaryTicket;

public class AlertSummaryTicketComparator implements Comparator<AlertSummaryTicket> {

	/**
	 * 期間内の発生回数の降順、同一の場合はチケットIDの昇順
	 */
	@Override
	public int compare(AlertSummaryTicket o1, AlertSummaryTicket o2) {

		if(o1 == null || o2 == null) {
			throw new IllegalArgumentException("引数がnullです。");
		}

		int ownOccuredCnt = o1.getOccuredCnt();
		int anotherOccuredCnt = o2.getOccuredCnt();

		if(ownOccuredCnt != anotherOccuredCnt) {
			return -(ownOccuredCnt - anotherOccuredCnt);
		}

		return o1.getKeyId() - o2.getKeyId();

	}

}
