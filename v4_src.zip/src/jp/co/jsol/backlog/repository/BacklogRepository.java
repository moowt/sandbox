package jp.co.jsol.backlog.repository;

import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import com.nulabinc.backlog4j.BacklogClient;
import com.nulabinc.backlog4j.BacklogClientFactory;
import com.nulabinc.backlog4j.BacklogException;
import com.nulabinc.backlog4j.Issue;
import com.nulabinc.backlog4j.IssueComment;
import com.nulabinc.backlog4j.IssueType;
import com.nulabinc.backlog4j.Project;
import com.nulabinc.backlog4j.api.option.AddIssueCommentParams;
import com.nulabinc.backlog4j.api.option.CreateIssueParams;
import com.nulabinc.backlog4j.api.option.GetIssuesCountParams;
import com.nulabinc.backlog4j.api.option.GetIssuesParams;
import com.nulabinc.backlog4j.api.option.UpdateIssueParams;
import com.nulabinc.backlog4j.conf.BacklogConfigure;
import com.nulabinc.backlog4j.conf.BacklogJpConfigure;
import com.nulabinc.backlog4j.conf.BacklogPackageConfigure;

import jp.co.jsol.backlog.model.IssueSearchCondition;
import jp.co.jsol.backlog.model.ProjectInfo;

/**
 * Backlogからチケット情報などを取得するリポジトリクラス。プロジェクト毎にインスタンスを生成すること。
 * @author Akio Yamamoto
 *
 */
public class BacklogRepository {

	protected BacklogClient backlog;
	private ProjectInfo pjInfo;

	/** パラメータ設定用のプロジェクトID */
	private String projectId;

	/** 課題検索時の１度に検索する件数。(MAX:100件) */
	private static final int SEARCH_ISSUE_SIZE = 100;

	public static BacklogRepository of(ProjectInfo pjInfo) {
		return new BacklogRepository(pjInfo);
	}

	private BacklogRepository(ProjectInfo pjInfo) {
		try {
			setConfig(pjInfo.getApiInfo().getUrl(), pjInfo.getApiInfo().getApiKey());
		} catch (MalformedURLException e) {
			throw new RuntimeException("Backlog接続失敗", e);
		}

		this.pjInfo = pjInfo;
		this.projectId = getProjectID();

	}

	private void setConfig(String url, String apikey) throws MalformedURLException {
		BacklogConfigure conf = null;
		//オンプレ環境
		if (url.startsWith("http")) {
			conf = new BacklogPackageConfigure(url);
		}
		//クラウド
		else {
			conf = new BacklogJpConfigure(url);
		}
		conf.apiKey(apikey);
		backlog = new BacklogClientFactory(conf).newClient();
	}

	/**
	 * 課題をID検索する。
	 * @param id 課題のIDの数字部分(例：TGIJ-123であれば、123)
	 * @return 課題の検索結果。該当レコードが存在しない場合は、nullを返却する。
	 */
	public Issue selectIssueByKeyId(int id) {
		String issueKey = pjInfo.getTicketNo(id);

		try {
			return backlog.getIssue(issueKey);

		} catch (BacklogException e) {

			// 該当レコードが存在しない場合、404エラーとなる。
			if (e.getStatusCode() == 404) {
				return null;
			}

			throw e;
		}

	}

	/**
	 * 課題をissueIdで検索する。
	 * @param issueId 各課題が内部的に持っているid
	 * @return 課題の検索結果。該当レコードが存在しない場合は、nullを返却する。
	 */
	public Issue selectIssueByIssueId(long issueId) {

		try {
			return backlog.getIssue(issueId);

		} catch (BacklogException e) {

			// 該当レコードが存在しない場合、404エラーとなる。
			if (e.getStatusCode() == 404) {
				return null;
			}

			throw e;
		}

	}

	/**
	 * 指定された検索条件に従って、課題を検索する。
	 * @param cond 検索条件。全検索の場合、nullを入力する。
	 * @return 検索条件を満たす課題リスト
	 */
	public List<Issue> selectIssues(IssueSearchCondition cond) {

		int offset = 0;

		//件数の取得
		int totalCount = getIssueCount(cond);
		List<Issue> responseList = new ArrayList<>();

		//1度に検索できる件数は限られているため、上限を超えている場合は複数回に分けて検索を行う
		while(offset < totalCount) {
			GetIssuesParams params = createIssueParams(cond, offset);
			responseList.addAll(backlog.getIssues(params));

			offset += SEARCH_ISSUE_SIZE;
		}


		responseList.sort(Comparator.comparing(Issue::getKeyId));
		return responseList;
	}

	/**
	 * 課題をキーワード検索する。半角スペース区切りで入力することで、AND検索が行われる。
	 * @param keyword キーワード(部分一致)
	 * @return 課題の検索結果リスト
	 */
	public List<Issue> selectIssuesByKeyword(String keyword) {

		if(keyword == null) {
			throw new IllegalArgumentException("キーワードを入力して下さい。");
		}

		GetIssuesParams params = new GetIssuesParams(Arrays.asList(projectId))
				.keyword(keyword);

		return backlog.getIssues(params);

	}


	private GetIssuesParams createIssueParams(IssueSearchCondition cond, int offset) {
		GetIssuesParams params = new GetIssuesParams(Arrays.asList(projectId));

		if (cond != null) {
			params.issueTypeIds(cond.getIssueTypeIds())
					.statuses(cond.getStatusTypes())
					.priorities(cond.getPriorityTypes())
					.parentChildType(GetIssuesParams.ParentChildType.valueOf(cond.getParentChildType().name()))
					.keyword(cond.getKeyWord())
					.createdSince(cond.getCreatedSince())
					.createdUntil(cond.getCreatedUntil());
		}

		params.count(SEARCH_ISSUE_SIZE);
		params.offset(offset);

		return params;
	}


	/**
	 * 指定された検索条件に従って、課題の件数を取得する。
	 * @param cond 検索条件。全検索の場合、nullを入力する。
	 * @return 検索条件を満たす課題の件数
	 */
	public int getIssueCount(IssueSearchCondition cond) {
		GetIssuesCountParams countParams = new GetIssuesCountParams(Arrays.asList(projectId));

		if(cond != null) {
		countParams.issueTypeIds(cond.getIssueTypeIds())
				.statuses(cond.getStatusTypes())
				.priorities(cond.getPriorityTypes())
				.parentChildType(GetIssuesCountParams.ParentChildType.valueOf(cond.getParentChildType().name()))
				.keyword(cond.getKeyWord())
				.createdSince(cond.getCreatedSince())
				.createdUntil(cond.getCreatedUntil());
		}

		return backlog.getIssuesCount(countParams);
	}

	/**
	 * 該当のプロジェクトに、課題を新規作成する。
	 * @param issueTypeName 課題のタイプ(タスクなど)
	 * @param summary タイトル
	 * @param description 本文
	 * @return 作成した課題のキーID(例：TGIF-123)
	 */
	public String insertIssue(String issueTypeName, String summary, String description) {

		CreateIssueParams params = new CreateIssueParams(projectId, summary, getIssueTypeId(issueTypeName),
				Issue.PriorityType.Normal);
		params.description(description);

		Issue issue = backlog.createIssue(params);

		if (issue == null) {
			return null;
		}

		return pjInfo.getTicketNo((int) issue.getKeyId());

	}

	public int updateIssue(UpdateIssueParams params) {
		try {

			backlog.updateIssue(params);
			return 200;

		} catch (BacklogException e) {
			// 割と適当ですごめんなさい
			if(e.getStatusCode() == 404 || e.getStatusCode() == 400) {
				return e.getStatusCode();
			}

			throw e;
		}
	}

	public String addComment(String ticketId, String comment) {

		AddIssueCommentParams params = new AddIssueCommentParams(ticketId, comment);

		IssueComment result = backlog.addIssueComment(params);

		return result.getIdAsString();
	}



	/**
	 * 課題のタイプ(種別)を取得する
	 * @param prjKey プロジェクトキー
	 * @param issueTypeName 種別名称
	 * */
	private String getIssueTypeId(String issueTypeName) {
		for (IssueType type : backlog.getIssueTypes(pjInfo.getProjectId())) {
			if (type.getName().equals(issueTypeName)) {
				return type.getIdAsString();
			}
		}
		return null;
	}

	/**
	 * プロジェクトIDを取得する
	 * @param prjKey プロジェクトキー
	 * @return Projectid
	 * */
	private String getProjectID() {
		for (Project type : backlog.getProjects()) {
			if (type.getProjectKey().equals(pjInfo.getProjectId())) {
				return type.getIdAsString();
			}
		}
		return null;
	}
}
