package jp.co.jsol.backlog.common;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

public class PropertyUtils {

	private static final String INIT_FILE_PATH = "backlogapi.properties";
	private static final Properties properties;

	private PropertyUtils() {
	}

	static {
		properties = new Properties();
		try {
			properties.load(Files.newBufferedReader(Paths.get(INIT_FILE_PATH), StandardCharsets.UTF_8));
		} catch (IOException e) {
			// ファイル読み込みに失敗
			System.out.println(String.format("ファイルの読み込みに失敗しました。ファイル名:%s", INIT_FILE_PATH));
		}
	}

	/**
	 * プロパティ値を取得する
	 *
	 * @param key キー
	 * @return 値
	 */
	public static String getProperty(final String key) {
		return getProperty(key, "");
	}

	/**
	 * プロパティ値を取得する
	 *
	 * @param key キー
	 * @param defaultValue デフォルト値
	 * @return キーが存在しない場合、デフォルト値
	 *          存在する場合、値
	 */
	public static String getProperty(final String key, final String defaultValue) {
		return properties.getProperty(key, defaultValue);
	}

	/**
	 * 前方一致するキーのプロパティ値をすべて取得する
	 * @param key キー
	 * @return 値のリスト
	 */
	public static Map<String, String> getStartMatchProperties(final String prefix) {

		Map<String, String> propList = new HashMap<>();

		for (Entry<Object, Object> e : properties.entrySet()) {

			// 絶対文字列でとれるはず
			String k = e.getKey().toString();
			String v = e.getValue().toString();

			if (k.startsWith(prefix)) {
				propList.put(k, v);
			}
		}

		return propList;

	}
}