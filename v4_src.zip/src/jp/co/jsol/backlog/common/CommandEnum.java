package jp.co.jsol.backlog.common;

import jp.co.jsol.backlog.controller.AlertAnalyzeAction;
import jp.co.jsol.backlog.controller.BaseAction;
import jp.co.jsol.backlog.controller.ExitAction;
import jp.co.jsol.backlog.controller.GetTicketForKeyAction;
import jp.co.jsol.backlog.controller.HelpAction;
import jp.co.jsol.backlog.controller.PostingTicketAction;
import jp.co.jsol.backlog.controller.SearchTicketAction;
import jp.co.jsol.backlog.controller.SetParentTicketAction;
import jp.co.jsol.backlog.controller.TicketDiffAction;

public enum CommandEnum {
	GET(new GetTicketForKeyAction(),"チケット取得機能", "指定したIDのチケット情報を取得します。コマンド: get (チケットキーID) (該当チケットをブラウザで開く場合 -o)  例:TGIF-xxxx -o")
	,DIFF(new TicketDiffAction(), "プロジェクト間のチケット差分確認機能","取得元にあって比較先に無いチケットの一覧を取得します。コマンド: diff")
	,CP(new PostingTicketAction(), "プロジェクト間のチケット転記機能", "別のプロジェクトのチケットを転記します。\n  コマンド: cp (タスクのチェックボックスを追加する場合 -t) (チケットキーID カンマ区切り)")
	,SEARCH(new SearchTicketAction(), "プロジェクト間横断検索機能", "指定したプロジェクトのチケットを検索します。コマンド：search (プロジェクトID カンマ区切り) "
			+ "\n  ※オプション：親課題を設定する場合 -p [All, NotChild, Child, NotChildNotParent, Parent]、キーワード検索する場合 -kw (キーワード カンマ区切り)を追加で入力して下さい。なお、キーワードはAND検索です。"
			+ "\n  例：search TGIF,OSSM_MAINTE -p Parent -kw 保守")
	,SETP(new SetParentTicketAction(), "親課題一括設定機能","複数の課題を一括で親課題に設定します。コマンド：setp (親課題チケットキーID) (完了にする場合 close) -c (子課題チケットID 可変長)"
			+ "\n  例：setp TGIF-xxxx close -c TGIF-aaaa,TGIF-bbbb,TGIF-cccc")
	,ALERTAZ(new AlertAnalyzeAction(), "アラート分析機能","あとで書く")
	,EXIT(new ExitAction(), "アプリケーション終了", "アプリケーションを終了し、ウィンドウを閉じます。")
	,HELP(new HelpAction(),"ヘルプ","ヘルプです。コマンドの利用方法が確認できます。");

	/** コマンド実行時に呼び出されるアクションクラス */
	private BaseAction action;
	/** コマンドの機能名 */
	private String functionName;
	/** コマンドの説明 */
	private String explanation;

	private CommandEnum(BaseAction action, String functionName, String explanation) {
		this.action = action;
		this.functionName = functionName;
		this.explanation = explanation;
	}

	public static BaseAction call(String cmdStr) throws IllegalArgumentException {
		String upperCmd = cmdStr.toUpperCase();

		for (CommandEnum cmd : CommandEnum.values()) {
			if(cmd.name().equals(upperCmd)) {
				return cmd.getAction();
			}
		}

		throw new IllegalArgumentException("入力されたコマンドは存在しません。:" + cmdStr);
	}


	public BaseAction getAction() {
		return action;
	}

	public String getFunctionName() {
		return functionName;
	}

	public String getExplanation() {
		return explanation;
	}

	public String lowerCmd() {
		return this.name().toLowerCase();
	}

}
