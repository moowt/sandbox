package jp.co.jsol.backlog.common;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

import com.nulabinc.backlog4j.Issue;

import jp.co.jsol.backlog.model.Ticket;

public class TicketUtils {

	public static final String TICKETNO_REGEX = "[-:]{0,1}\\d{1,}";

	/** プライベートコンストラクタ */
	private TicketUtils() {};

	public static Ticket setTicketFromIssue(Ticket ticket, Issue issue) {

		if(ticket == null) {
			ticket = new Ticket();
		}

		ticket.setIssueId(issue.getId());
		ticket.setTicketId(issue.getIssueKey());
		ticket.setSummary(issue.getSummary());
		ticket.setStatus(issue.getStatus().getName());

		return ticket;
	}

	public static Ticket convertTicketFromIssue(Issue issue) {

		return setTicketFromIssue(new Ticket(), issue);

	}

	/**
	 * 比較先のプロジェクトのタイトルに記載されているチケットIDを抽出する。
	 * [注意]チケットIDはプレフィックス(P)から始まり「P-xxx」「P:xxx」「Pxxx」のいずれかの形式であること。
	 * @param title チケットのタイトル
	 * @return チケットのタイトルに記載されているチケットID
	 */
	public static int pollOutKeyId(String prefix, String title) {

		Pattern p = Pattern.compile(prefix + TICKETNO_REGEX);
		Matcher m = p.matcher(title);

		if (!m.find()) {
			return -1;
		}
		return Integer.parseInt(m.group().replaceAll("[^\\d]", ""));
	}

	public static String nowStr() {
		return LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss"));
	}

	public static String CRLF() {
		return StringUtils.CR + StringUtils.LF;
	}
}
