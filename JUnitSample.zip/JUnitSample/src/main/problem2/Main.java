package main.problem2;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<String> inputs = List.of(
                "error: xxxxxxx",
                "info: yyyyyyyyyy",
                "error: zzzzz"
        );
        System.out.println(new SampleLogFilter().filter(inputs, "error"));
    }
}
