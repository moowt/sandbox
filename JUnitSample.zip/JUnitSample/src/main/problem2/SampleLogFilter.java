package main.problem2;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * いけてないログフィルタ
 */
public class SampleLogFilter {

    /**
     * 指定した文字列を含むログを抽出する。
     * 抽出後の結果が0件である場合は、"None"と出力する。
     * @param inputs 抽出元のログ(リスト)
     * @param rule 抽出対象の文字列
     * @return 抽出後のログ(リスト)
     */
    public List<String> filter(List<String> inputs, String rule) {

        if (Objects.isNull(rule)) {
           throw new RuntimeException("抽出条件が指定されていません。");
        }
        return inputs.stream().filter(s -> s.startsWith(rule)).collect(Collectors.toList());
    }
}
