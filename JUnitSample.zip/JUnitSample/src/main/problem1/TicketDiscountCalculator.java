package main.problem1;

import java.time.DayOfWeek;
import java.time.LocalDate;

/**
 * いけてないチケット料金計算機
 */
public class TicketDiscountCalculator {

    /** 通常のチケット価格 */
    public static final int DEFAULT_PRICE = 2000;
    /** 平日割の割引率 */
    public static final double WEEKDAY_DISCOUNT_RATE = 0.8;
    /** 割引券有の割引率 */
    public static final double TICKET_DISCOUNT_RATE = 0.9;

    /**
     * 映画館のチケット料金を計算する。
     * ・基本料金は2000円
     * ・割引券提示の場合は10%オフ
     * ・平日は20%オフ
     * ただし、割引の併用は不可
     * 割引条件が重なる場合は割引率の高い方が適用される
     * @param date 開催日
     * @param hasDiscount 割引券の有無
     * @return 割引後の料金
     */
    public int getDiscountPrice(LocalDate date, boolean hasDiscount) {

        var discountPrice = DEFAULT_PRICE;

        // 平日割の適用
        if (isWeekday(date)) {
            discountPrice *= WEEKDAY_DISCOUNT_RATE;
        }
        // 割引券提示
        if (hasDiscount) {
            discountPrice *= TICKET_DISCOUNT_RATE;
        }
        return discountPrice;
    }

    /**
     * 平日判定。
     * @param date 日付
     * @return 平日である場合はtrue, そうでない場合はfalseを返却する。
     */
    private boolean isWeekday(LocalDate date) {
        return date.getDayOfWeek().equals(DayOfWeek.SATURDAY) || date.getDayOfWeek().equals(DayOfWeek.SUNDAY);
    }
}
