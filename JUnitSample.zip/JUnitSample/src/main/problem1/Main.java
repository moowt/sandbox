package main.problem1;

import java.time.LocalDate;

public class Main {

    public static void main(String[] args) {
        System.out.println(new TicketDiscountCalculator().getDiscountPrice(LocalDate.of(2023,9,11), true));
    }
}
