package jp.co.jsol.backlog.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import jp.co.jsol.backlog.common.TicketUtils;
import jp.co.jsol.backlog.model.IssueSearchCondition;
import jp.co.jsol.backlog.model.IssueSearchCondition.ParentChildType;
import jp.co.jsol.backlog.model.ProjectInfo;
import jp.co.jsol.backlog.model.Ticket;
import jp.co.jsol.backlog.repository.BacklogRepository;

public class SearchTicketService {

	public List<Ticket> doSearch(List<ProjectInfo> pjInfoList, ParentChildType parentChildType, String keyWords) {

		List<Ticket> ticketList = new ArrayList<>();

		for (ProjectInfo pjInfo : pjInfoList) {

			BacklogRepository repository = BacklogRepository.of(pjInfo);

			IssueSearchCondition cond = new IssueSearchCondition();
			cond.setKeyWord(keyWords).setParentChildType(parentChildType);

			List<Ticket> results =  repository.selectIssues(cond).stream()
					.map(is -> TicketUtils.convertTicketFromIssue(is))
					.collect(Collectors.toList());

			ticketList.addAll(results);


		}

		return ticketList;

	}

}
