package jp.co.jsol.backlog.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import com.nulabinc.backlog4j.Issue;

import jp.co.jsol.backlog.common.PropertyUtils;
import jp.co.jsol.backlog.common.TicketUtils;
import jp.co.jsol.backlog.model.IssueSearchCondition;
import jp.co.jsol.backlog.model.ProjectInfo;
import jp.co.jsol.backlog.model.Ticket;
import jp.co.jsol.backlog.repository.BacklogRepository;

/**
 * 2つのBacklogプロジェクトから、チケットの差分を取得するサービス.
 * @author Akio Yamamoto
 *
 */
public class TicketDiffService {

	private static final String INPUT_PROJECT = PropertyUtils.getProperty("diff.project.input");
	private static final String COMPARE_PROJECT = PropertyUtils.getProperty("diff.project.compare");

	/**
	 * 2つのプロジェクトからのチケット起票の差分を取得する。
	 * [注意]取得元、比較先ともにステータスが「完了」であるものはパフォーマンス向上のため省いている.
	 * 運用上問題ないと思われるが、既に比較先で完了したチケットも結果表示される.
	 * @return 取得元プロジェクトに存在し、比較先プロジェクトに存在しないチケット
	 */
	public List<Ticket> getUnvotedTickets() {

		// インプット元のプロジェクトから完了していないチケットを取得
		ProjectInfo inputPj = ProjectInfo.of(INPUT_PROJECT);
		BacklogRepository inputRepository = BacklogRepository.of(ProjectInfo.of(INPUT_PROJECT));

		IssueSearchCondition inputCondition = new IssueSearchCondition()
				.addStatusTypes(Issue.StatusType.Open, Issue.StatusType.InProgress, Issue.StatusType.Resolved,
						Issue.StatusType.Custom);

		List<Issue> inputList = inputRepository.selectIssues(inputCondition);



		// 突合のため、比較先のプロジェクトからチケットを取得
		BacklogRepository outputRepository = BacklogRepository.of(ProjectInfo.of(COMPARE_PROJECT));

		IssueSearchCondition compareCondition = new IssueSearchCondition()
				.addStatusTypes(Issue.StatusType.Open, Issue.StatusType.InProgress, Issue.StatusType.Resolved);

		final String TICKETNO_REGEX = ".*"+ inputPj.getPrefix() + "[-:]{0,1}\\d{1,}.*";

		Set<Integer> compareSet = outputRepository.selectIssues(compareCondition)
				.stream()
				.filter(is -> is.getSummary().matches(TICKETNO_REGEX))
				.map(is -> TicketUtils.pollOutKeyId(inputPj.getPrefix(), is.getSummary()))
				.collect(Collectors.toSet());


		compareSet.remove(-1); //抽出できなかったものは-1

		List<Integer> excludeList = createExcludeList(inputPj);


		// 突合し、比較先に存在しないチケットを抽出して返却
		List<Ticket> unvotedList = new ArrayList<>();
		for (Issue inputIssue : inputList) {
			int keyId = (int)inputIssue.getKeyId();

			if(excludeList.contains(keyId)) {
				continue;
			}

			if (compareSet.contains(keyId)) {
				continue;
			}

			unvotedList.add(TicketUtils.convertTicketFromIssue(inputIssue));

		}

		return unvotedList;
	}

	private List<Integer> createExcludeList(ProjectInfo inputPj) {
		// プロパティで設定した除外リスト分を結果から取り除く
		String excludesStr = PropertyUtils.getProperty("diff.project.input.exclude");

		if(StringUtils.isEmpty(excludesStr)) {
			return new ArrayList<>();
		}

		return Arrays.stream(excludesStr.split(","))
				.filter(ticketNo -> ticketNo.startsWith(inputPj.getProjectId()))
				.map(ticketNo -> Integer.parseInt(ticketNo.split("-")[1]))
				.collect(Collectors.toList());
	}
}
