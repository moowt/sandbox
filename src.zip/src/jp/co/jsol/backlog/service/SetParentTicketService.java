package jp.co.jsol.backlog.service;

import java.util.ArrayList;
import java.util.List;

import com.nulabinc.backlog4j.Issue.StatusType;
import com.nulabinc.backlog4j.api.option.UpdateIssueParams;

import jp.co.jsol.backlog.model.ProjectInfo;
import jp.co.jsol.backlog.model.Ticket;
import jp.co.jsol.backlog.repository.BacklogRepository;

/**
 * 親課題設定のサービスクラス
 * @author Akio Yamamoto
 *
 */
public class SetParentTicketService {

	/**
	 * 引数のチケットに対して、親課題設定および、設定に応じて子課題のクローズを行う。
	 * 各チケットごとに1件ずつ更新し、更新結果の一覧を返却する。
	 * チケットが存在しない場合、変更点が無い場合などは、チケット更新されない。
	 * @param parentKeyId 親課題に設定するチケット
	 * @param childTaskKeyIdList 子課題となるチケットのリスト
	 * @param isSetClosed trueの場合、チケットをクローズも併せて実行する
	 * @return 各チケットの更新結果を返却する。
	 */
	public List<String> set(String parentKeyId, List<String> childTaskKeyIdList, boolean isSetClosed) {

		GetTicketForKeyService getTaskService = new GetTicketForKeyService();

		Ticket parentTask = getTaskService.searchForKey(parentKeyId, false);

		if (parentTask == null) {
			throw new IllegalArgumentException("[ERROR]親課題が取得できません。:" + parentKeyId);
		}

		ProjectInfo pjInfo = ProjectInfo.of(parentKeyId.split("-")[0]);
		BacklogRepository repository = BacklogRepository.of(pjInfo);

		List<String> messages = new ArrayList<>();

		// 1件ずつ更新し、更新結果に応じたメッセージをリストに詰めて返却する
		for (String child : childTaskKeyIdList) {

			UpdateIssueParams params = createParams(isSetClosed, parentTask, child);
			messages.add(updateOne(repository, params));
		}

		return messages;
	}

	private UpdateIssueParams createParams(boolean isSetClosed, Ticket parentTask, String child) {
		UpdateIssueParams params = new UpdateIssueParams(child);

		params.parentIssueId(parentTask.getIssueId());
		if (isSetClosed) {
			params.status(StatusType.Closed);
		}
		return params;
	}

	private String updateOne(BacklogRepository repository, UpdateIssueParams params) {

		int statusCode = repository.updateIssue(params);

		switch (statusCode) {
		case 200:
			return "[INFO]チケットの更新に成功しました。:" + params.getIssueIdOrKeyString();
		case 400:
			return "[WARN]該当の子チケットは変更されませんでした。:" + params.getIssueIdOrKeyString();
		case 404:
			return "[WARN]該当の子チケットは存在しません。:" + params.getIssueIdOrKeyString();
		default:
			return "[WARN]本来は表示されないメッセージ。:" + params.getIssueIdOrKeyString();

		}

	}
}
