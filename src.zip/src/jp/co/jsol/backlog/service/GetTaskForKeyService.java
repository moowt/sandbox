package jp.co.jsol.backlog.service;

import org.apache.commons.lang3.StringUtils;

import com.nulabinc.backlog4j.Issue;

import jp.co.jsol.backlog.common.ProjectInfoEnum;
import jp.co.jsol.backlog.common.TaskUtils;
import jp.co.jsol.backlog.model.Task;
import jp.co.jsol.backlog.repository.BacklogRepository;

/**
 * BackLogのキーIDをもとにチケット情報を取得するサービス.
 * @author Akio Yamamoto
 *
 */
public class GetTaskForKeyService {

	/**
	 * キーに紐づくチケット情報を取得する
	 * @param key キーID(プロジェクト名+連番)
	 * @return チケット情報。ただし、該当のチケットが存在しない場合はnullを返却する。
	 */
	public Task searchForKey(String key) throws IllegalArgumentException {

		if(StringUtils.isEmpty(key)) {
			throw new IllegalArgumentException("[ERROR]キーの入力がありません。");
		}

		String[] splitedKey = key.split("-");

		if (splitedKey.length != 2 || !StringUtils.isNumeric(splitedKey[1])) {
			throw new IllegalArgumentException("[ERROR]入力されたキーは不正です。:" + key);
		}

		ProjectInfoEnum pjInfo = ProjectInfoEnum.getFromPjKey(splitedKey[0]);

		if (pjInfo == null) {
			throw new IllegalArgumentException("[ERROR]入力されたプロジェクトは存在しません。;" + splitedKey[0]);
		}

		BacklogRepository repository = BacklogRepository.of(pjInfo);
		Issue issue = repository.selectIssueByKeyId(Integer.parseInt(splitedKey[1]));

		if(issue == null) {
			return null;
		}

		return TaskUtils.convertTaskFromIssue(issue);
	}
}
