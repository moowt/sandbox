package jp.co.jsol.backlog.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.nulabinc.backlog4j.Issue;

import jp.co.jsol.backlog.common.ProjectInfoEnum;
import jp.co.jsol.backlog.common.PropertyUtils;
import jp.co.jsol.backlog.common.TaskUtils;
import jp.co.jsol.backlog.model.Task;
import jp.co.jsol.backlog.repository.BacklogRepository;

/**
 * Backlogプロジェクトのチケットを別プロジェクトに転記するサービス.
 * @author Akio Yamamoto
 *
 */
public class PostingTaskService {

	private static final String OUTPUT_PROJECT_NAME = PropertyUtils.getProperty("cp.project.output");

	private ProjectInfoEnum outputPjInfo = ProjectInfoEnum.getFromPjKey(OUTPUT_PROJECT_NAME);

	private BacklogRepository outputRepository = BacklogRepository.of(outputPjInfo);

	private GetTaskForKeyService getTaskService = new GetTaskForKeyService();


	/**
	 * チケットの転記を行う。転記されたチケットは、課題タイプ、タイトル、本文、優先度が以下の通り設定される。
	 * 課題タイプ：backlogapi.propertiesに記載されたタイプ。存在しない場合は「その他」
	 * タイトル：元チケットの番号およびタイトル
	 * 本文：元チケットのURL
	 * 優先度：中
	 * 入力されたタスクキーIDが存在しない場合は、転記は行わない。
	 * @param taskKeyIds タスクキーIDの一覧(例:TGIF-123)
	 * @return 転記の結果を表すメッセージのリスト
	 */
	public List<String> post(List<String> taskKeyIds) {

		if (taskKeyIds == null || taskKeyIds.isEmpty()) {
			throw new IllegalArgumentException("[ERROR]入力値が存在しません。");
		}
		List<String> resultList = new ArrayList<>();

		for (String taskKeyId : taskKeyIds) {
			//１つずつ転記実施
			resultList.add(post(taskKeyId));
		}

		return resultList;
	}

	private String post(String taskKeyId) {

		// 取得元からチケット情報を抽出する
		Task task;

		try {
			task = getTaskService.searchForKey(taskKeyId);
		} catch (IllegalArgumentException e) {
			return e.getMessage();
		}

		if (task == null) {
			return "[ERROR]該当のチケットは存在しません。:" + taskKeyId;
		}

		// 出力先に該当チケットが既に存在しているか確認
		if (isAlreadyExist(task)) {
			return "[ERROR]転記しようとしているチケットは既に存在します。:" + taskKeyId;
		}

		// 転記
		String issueType = PropertyUtils.getProperty("cp.issue.type", "その他");
		String description = String.join("", "元チケット", StringUtils.CR, StringUtils.LF,
				task.getPjInfo().getTicketUrl(task.getKeyId()));

		String outputKeyId = outputRepository.insertIssue(issueType, createSummary(task), description);

		return String.join("", "[INFO]元チケット ",taskKeyId," を ", outputKeyId," に転記しました。");
	}

	private String createSummary(Task task) {
		ProjectInfoEnum pjInfo = task.getPjInfo();
		return String.join("", "【保守】",pjInfo.getPrefix(),"-", Integer.toString(task.getKeyId()), " ", task.getSummary());
	}

	private boolean isAlreadyExist(Task task) {
		List<Issue> chekingIssues = outputRepository.selectIssuesByKeyword(task.getSummary());

		if (chekingIssues.isEmpty()) {
			return false;
		}

		for (Issue issue : chekingIssues) {
			int polledOutKeyId = TaskUtils.pollOutKeyId(issue.getSummary());

			if (polledOutKeyId == task.getKeyId()) {
				return true;
			}
		}

		return false;
	}

}
