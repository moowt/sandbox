package jp.co.jsol.backlog.controller;

import java.util.List;

import jp.co.jsol.backlog.model.Ticket;
import jp.co.jsol.backlog.service.TicketDiffService;

public class TicketDiffAction extends BaseAction {

	TicketDiffService service = new TicketDiffService();

	@Override
	protected boolean isValid(String... args) {
		if (args == null || args.length != 1) {
			println("[ERROR]第二引数以降は不要です。");
			println("[ERROR]取得元・比較先プロジェクトを変更する場合はプロパティファイルを修正してください。");
			return false;
		}

		return true;
	}

	@Override
	protected void callService(String... args) {

		List<Ticket> ticketList = service.getUnvotedTickets();

		if (ticketList.isEmpty()) {
			println("[INFO]比較先プロジェクトに未起票のチケットは存在しません。");
			return;
		}

		println("[INFO]未起票のチケット:" + ticketList.size() + "件");

		for (Ticket task : ticketList) {
			println(String.join(" ", task.getTicketId(), task.getSummary(), "[" + task.getStatus() + "]"));
		}

	}

}
