package jp.co.jsol.backlog.controller;

import java.util.List;

import jp.co.jsol.backlog.model.Task;
import jp.co.jsol.backlog.service.TaskDiffService;

public class TaskDiffAction extends BaseAction {

	TaskDiffService service = new TaskDiffService();

	@Override
	protected boolean isValid(String... args) {
		if (args == null || args.length != 1) {
			println("[ERROR]第二引数以降は不要です。");
			println("[ERROR]取得元・比較先プロジェクトを変更する場合はプロパティファイルを修正してください。");
			return false;
		}

		return true;
	}

	@Override
	protected void callService(String... args) {

		List<Task> taskList = service.getUnvotedTasks();

		if (taskList.isEmpty()) {
			println("[INFO]比較先プロジェクトに未起票のチケットは存在しません。");
			return;
		}

		println("[info]未起票のチケット:" + taskList.size() + "件");

		for (Task task : taskList) {
			println(String.join(" ", task.getTaskKeyId(), task.getSummary(), "[" + task.getStatus() + "]"));
		}

	}

}
