package jp.co.jsol.backlog.controller;

import jp.co.jsol.backlog.common.CommandEnum;
import jp.co.jsol.backlog.model.Task;
import jp.co.jsol.backlog.service.GetTaskForKeyService;

public class GetTaskForKeyAction extends BaseAction {

	private GetTaskForKeyService service = new GetTaskForKeyService();

	@Override
	protected void init() {

	}

	@Override
	protected boolean isValid(String... args) {

		if(args == null || args.length != 2) {
			println("[ERROR]入力形式は「" + CommandEnum.GET.lowerCmd() + " チケットキーID」です。");
			return false;
		}

		return true;
	}

	@Override
	protected void callService(String... args) {

		Task resultTask = null;

		try {
			 resultTask = service.searchForKey(args[1]);

		} catch (IllegalArgumentException e) {
			println(e.getMessage());
			return;
		}

		if(resultTask == null) {
			println("[INFO]該当のIDのチケットは存在しません。:" + args[1]);
		} else {
			println(String.join(" ", resultTask.getTaskKeyId(), resultTask.getSummary(), resultTask.getStatus()));
		}

	}

	@Override
	protected void end() {

	}



}
