package jp.co.jsol.backlog.controller;

import java.util.Arrays;

import jp.co.jsol.backlog.common.CommandEnum;
import jp.co.jsol.backlog.model.Ticket;
import jp.co.jsol.backlog.service.GetTicketForKeyService;

public class GetTicketForKeyAction extends BaseAction {

	private GetTicketForKeyService service = new GetTicketForKeyService();


	@Override
	protected boolean isValid(String... args) {

		if (args == null || args.length < 2) {
			println("[ERROR]入力形式は「" + CommandEnum.GET.lowerCmd() + " チケットキーID (-o)」です。");
			return false;
		}

		return true;
	}

	@Override
	protected void callService(String... args) {

		Ticket resultTicket = null;

		boolean isOpen = Arrays.asList(args).contains("-o");
		if(isOpen) {
			println("[INFO]該当チケットをブラウザで開きます。");
		}


		try {
			resultTicket = service.searchForKey(args[1], isOpen);

		} catch (IllegalArgumentException e) {
			println(e.getMessage());
			return;

		} catch (RuntimeException e) {
			println(e.getMessage());
			return;
		}

		if (resultTicket == null) {
			println("[INFO]該当のIDのチケットは存在しません。:" + args[1]);
		} else {
			println(String.join(" ", resultTicket.getTicketId(), resultTicket.getSummary(), "[" + resultTicket.getStatus() +
					"]"));
		}

	}


}
