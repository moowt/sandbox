package jp.co.jsol.backlog.controller;

import java.util.Arrays;

import jp.co.jsol.backlog.common.PrintUtils;
import jp.co.jsol.backlog.common.TicketUtils;

/**
 * アクションクラスの基底クラス。全てのアクションクラスは、本クラスを継承すること。
 * @author Akio Yamamoto
 *
 */
public abstract class BaseAction {

	/**
	 * ApplicationStarterから直接呼び出すメソッド。
	 * @param args コンソールの入力値
	 */
	public final void execute(String... args) {
		init(args);

		if(!isValid(args)) {
			println("[ERROR]入力値が不正です。再度入力して下さい。:" + Arrays.toString(args));
			return;
		}

		callService(args);

		end();
	}


	/**
	 * 初期化処理。必要である場合はオーバーライドして利用すること。
	 */
	protected void init(String... args) {}

	/**
	 * コンソールの入力値チェックを行う。なお、業務的なチェックはサービスクラスにて行うこと。
	 * @param args コンソールの入力値
	 * @return チェックOKの場合True、NGの場合False
	 */
	protected abstract boolean isValid(String... args);

	/**
	 * サービスクラスを呼び出し、コンソールへの結果表示準備を行う。
	 * @param args コンソールの入力値。
	 */
	protected abstract void callService(String... args);

	/**
	 * 事後処理。必要である場合はオーバーライドして利用すること。
	 */
	protected void end() {
		println(TicketUtils.CRLF());
	}

	protected void println(String message) {
		PrintUtils.println(message);

	}
}
