package jp.co.jsol.backlog.controller;

public class ExitAction extends BaseAction {

	@Override
	protected void init(String... args) {
		println("アプリケーションを終了します。");
	}

	@Override
	protected boolean isValid(String... args) {

		return true;
	}

	@Override
	protected void callService(String... args) {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// 問題無いため握り潰し
		}

	}

	protected void end() {
		super.end();
		System.exit(0);
	}

}
