package jp.co.jsol.backlog.controller;

import java.util.Arrays;
import java.util.List;

import jp.co.jsol.backlog.common.CommandEnum;
import jp.co.jsol.backlog.service.PostingTicketService;

public class PostingTicketAction extends BaseAction {

	PostingTicketService service = new PostingTicketService();


	@Override
	protected boolean isValid(String... args) {

		if(args == null || args.length <= 1) {
			println("[ERROR]入力形式は「" + CommandEnum.CP.lowerCmd() + " チケットキーID(カンマ区切り)」です。");
			return false;
		}

		return true;
	}

	@Override
	protected void callService(String... args) {
		List<String> inputList = Arrays.asList(args[args.length -1].split(","));

		boolean hasTasks = "-t".equals(args[1]);

		List<String> resultList = service.post(inputList, hasTasks);
		println("実行件数:" + resultList.size());

		for (String result : resultList) {
			println(result);
		}
	}


}
