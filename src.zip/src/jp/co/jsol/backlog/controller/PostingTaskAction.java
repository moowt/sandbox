package jp.co.jsol.backlog.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import jp.co.jsol.backlog.common.CommandEnum;
import jp.co.jsol.backlog.service.PostingTaskService;

public class PostingTaskAction extends BaseAction {

	PostingTaskService service = new PostingTaskService();


	@Override
	protected boolean isValid(String... args) {

		if(args == null || args.length <= 1) {
			println("[ERROR]入力形式は「" + CommandEnum.CP.lowerCmd() + " チケットキーID(可変長)」です。");
			return false;
		}

		return true;
	}

	@Override
	protected void callService(String... args) {
		List<String> inputList = new ArrayList<>(Arrays.asList(args));
		inputList.remove(0); // 1要素目はコマンド名のため、除去

		List<String> resultList = service.post(inputList);
		println("実行件数:" + resultList.size());

		for (String result : resultList) {
			println(result);
		}
	}


}
