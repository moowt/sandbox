package jp.co.jsol.backlog.controller;

import jp.co.jsol.backlog.common.CommandEnum;
import jp.co.jsol.backlog.common.PrintUtils;

public class HelpAction extends BaseAction {

	@Override
	protected boolean isValid(String... args) {
		return true;
	}

	@Override
	protected void callService(String... args) {
		for (CommandEnum cmd : CommandEnum.values()) {
			PrintUtils.println(
					String.join("", String.format("%-6s", cmd.lowerCmd()), ":", cmd.getExplanation()));
		}

	}

}
