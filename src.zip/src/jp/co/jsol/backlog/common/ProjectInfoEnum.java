package jp.co.jsol.backlog.common;

import static jp.co.jsol.backlog.common.ApiInfoEnum.*;

import org.apache.commons.lang3.StringUtils;

public enum ProjectInfoEnum {

	AKITASK(MY_BACKLOG, "")
	,TGIF(JSOLDI, "")
	,OSHISON_OM(JSOLDI, "")
	,OSSM_MAINTE(OSSM, "M")
	,OSSM19(OSSM, "19")
	,OSSM18(OSSM, "18")
	,OSSM_SYSTEM(OSSM, "S");

	/** プロジェクトに紐づくAPI情報 */
	private ApiInfoEnum apiInfo;
	/** プロジェクトを表す接頭辞 */
	private String prefix;

	private ProjectInfoEnum(ApiInfoEnum apiInfo, String prefix) {
		this.apiInfo = apiInfo;
		this.prefix = prefix;
	}

	public ApiInfoEnum getApiInfo() {
		return apiInfo;
	}

	public String getTaskKey(int no) {
		return this.name() + "-" + no;
	}

	public String getPrefix() {
		return prefix;
	}

	public static ProjectInfoEnum getFromPjKey(String pjKey) {

		if(StringUtils.isEmpty(pjKey)) {
			return null;
		}

		for (ProjectInfoEnum pjInfo : ProjectInfoEnum.values()) {
			if(pjKey.equals(pjInfo.name())){
				return pjInfo;
			}
		}

		return null;
	}

	public String getTicketUrl(int no) {
		return apiInfo.getUrl() + "view/" + getTaskKey(no);
	}

}
