package jp.co.jsol.backlog.common;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

import com.nulabinc.backlog4j.Issue;

import jp.co.jsol.backlog.model.Task;

public class TaskUtils {

	private static final String TASKNO_REGEX = "[MS][-:]{0,1}\\d{1,}";

	/** プライベートコンストラクタ */
	private TaskUtils() {};

	public static Task convertTaskFromIssue(Issue issue) {

		Task task = new Task();
		task.setTaskKeyId(issue.getIssueKey());
		task.setSummary(issue.getSummary());
		task.setStatus(issue.getStatus().getName());

		return task;
	}

	/**
	 * 比較先のプロジェクトのタイトルに記載されているチケットIDを抽出する。
	 * [注意]チケットIDは「MまたはS」から始まり「M-xxx」「M:xxx」「Mxxx」のいずれかの形式であること。
	 * @param title チケットのタイトル
	 * @return チケットのタイトルに記載されているチケットID
	 */
	public static int pollOutKeyId(String title) {

		Pattern p = Pattern.compile(TASKNO_REGEX);
		Matcher m = p.matcher(title);

		if (!m.find()) {
			return -1;
		}
		return Integer.parseInt(m.group().replaceAll("[^\\d]", ""));
	}

	public static String nowStr() {
		return LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss"));
	}

	public static String CRLF() {
		return StringUtils.CR + StringUtils.LF;
	}
}
