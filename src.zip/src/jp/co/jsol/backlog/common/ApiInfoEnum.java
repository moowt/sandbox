package jp.co.jsol.backlog.common;

public enum ApiInfoEnum {

	MY_BACKLOG("https://moowt83.backlog.com/")
	,JSOLDI("https://jsolid.backlog.com/")
	,OSSM("https://oshiete18.backlog.com/");

	private ApiInfoEnum(String url) {
		this.url = url;
	}

	private String url;

	public String getUrl() {
		return url;
	}

	public String getApiKey() {
		String propertyKey = "backlog.api.key." + this.name().toLowerCase();
		return PropertyUtils.getProperty(propertyKey);
	}

}