package jp.co.jsol.backlog;

import java.util.Scanner;

import jp.co.jsol.backlog.common.CommandEnum;
import jp.co.jsol.backlog.common.PrintUtils;
import jp.co.jsol.backlog.common.PropertyUtils;

/**
 * 本アプリケーションのドライバクラス
 * @author Akio Yamamoto
 *
 */
public class ApplicationStarter {

	public static void main(String[] args) {

		setProxy();

		Scanner stdIn = new Scanner(System.in);
		String line;

		PrintUtils.println("[INFO]アプリケーションが起動しました。利用方法を確認する場合「help」と入力して下さい。");
		PrintUtils.print("[INFO]コマンドを入力して下さい:");

		while ((line = stdIn.nextLine()) != null) {

			try {
				CommandEnum.call(line.split(" ")[0]).execute(line.split(" "));

			} catch (IllegalArgumentException e) {

				PrintUtils.println(e.getMessage());

			} catch (Exception e) {

				PrintUtils.println("[ERROR]予期せぬエラーが発生しました。");
				e.printStackTrace();

			}

			PrintUtils.print("[INFO]コマンドを入力して下さい:");
		}

		stdIn.close();
	}

	private static void setProxy() {

		boolean availableProxy = Boolean.getBoolean(PropertyUtils.getProperty("proxy.set"));

		if (availableProxy) {
			System.setProperty("proxySet", PropertyUtils.getProperty("proxy.set"));
			System.setProperty("http.proxyHost", PropertyUtils.getProperty("proxy.host"));
			System.setProperty("http.proxyPort", PropertyUtils.getProperty("proxy.port"));
			System.setProperty("https.proxyHost", PropertyUtils.getProperty("proxy.host"));
			System.setProperty("https.proxyPort", PropertyUtils.getProperty("proxy.port"));
			System.setProperty("nonProxyHosts", PropertyUtils.getProperty("proxy.nonProxyHosts"));
		}
	}

}
