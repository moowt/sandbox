package jp.co.jsol.backlog.model;

import jp.co.jsol.backlog.common.ProjectInfoEnum;

/** コンソール表示用の課題を表すモデル */
public class Task {

	/** タスクキー */
	private String taskKeyId;
	/** タイトル */
	private String summary;
	/** ステータス */
	private String status;

	public String getTaskKeyId() {
		return taskKeyId;
	}
	public void setTaskKeyId(String taskKey) {
		this.taskKeyId = taskKey;
	}
	public String getSummary() {
		return summary;
	}
	public void setSummary(String summary) {
		this.summary = summary;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	public int getKeyId() {
		return Integer.parseInt(taskKeyId.split("-")[1]);
	}

	public ProjectInfoEnum getPjInfo() {
		return ProjectInfoEnum.getFromPjKey(taskKeyId.split("-")[0]);
	}

	@Override
	public String toString() {
		return "Task [taskKeyId=" + taskKeyId + ", summary=" + summary + ", status=" + status + "]";
	}


}
