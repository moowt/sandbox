package jp.co.jsol.backlog.model;

import org.apache.commons.lang3.StringUtils;

import jp.co.jsol.backlog.common.PropertyUtils;

/**
 * API接続情報に対するモデル.
 * @author Akio Yamamoto
 *
 */
public class ApiInfo {

	/** API連携する対象のbacklogのスペースID */
	private String spaceId;

	/** API連携する対象のbacklogのURL */
	private String url;

	/** APIにアクセスするためのキー */
	private String apiKey;

	/** staticファクトリー. スペースIDに紐づく情報がプロパティに存在しない場合はエラーとする. */
	public static ApiInfo of(String spaceId) {
		String url = PropertyUtils.getProperty("apiinfo." + spaceId + ".url");
		String apiKey = PropertyUtils.getProperty("apiinfo." + spaceId + ".apikey");

		if (StringUtils.isEmpty(url)) {
			throw new IllegalArgumentException("【ERROR】該当のスペースIDに対するURLがプロパティに定義されていません。:" + spaceId);
		}

		if(StringUtils.isEmpty(apiKey)) {
			throw new IllegalArgumentException("【ERROR】該当のスペースIDに対するAPIキーがプロパティに定義されていません。:" + spaceId);
		}

		return new ApiInfo(spaceId, url, apiKey);

	}


	private ApiInfo(String spaceId, String url, String apiKey) {
		this.spaceId = spaceId;
		this.url = url;
		this.apiKey = apiKey;
	}


	public String getSpaceId() {
		return spaceId;
	}


	public void setSpaceId(String spaceId) {
		this.spaceId = spaceId;
	}


	public String getUrl() {
		return url;
	}


	public void setUrl(String url) {
		this.url = url;
	}


	public String getApiKey() {
		return apiKey;
	}


	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}


	@Override
	public String toString() {
		return "ApiInfo [spaceId=" + spaceId + ", url=" + url + ", apiKey=" + apiKey + "]";
	}




}
