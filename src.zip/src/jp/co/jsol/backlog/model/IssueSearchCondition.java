package jp.co.jsol.backlog.model;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.nulabinc.backlog4j.Issue;
import com.nulabinc.backlog4j.Issue.PriorityType;
import com.nulabinc.backlog4j.Issue.StatusType;

/**
 * 課題の検索条件を表すクラス
 * @author Akio Yamamoto
 *
 */
public class IssueSearchCondition {

	/** 課題タイプ(タスク、ToDoなど) */
	private List<String> issueTypeIds = new ArrayList<>();

	/** ステータスタイプ(処理中、完了など) */
	private List<Issue.StatusType> statusTypes = new ArrayList<>();

	/** 優先度 */
	private List<Issue.PriorityType> priorityTypes = new ArrayList<>();


	/** 親子タイプ(デフォルトはAll) */
	private ParentChildType parentChildType = ParentChildType.All;

	/** キーワード(半角スペース区切り)。設定なしの場合、空文字 */
	private String keyWord = "";



	public IssueSearchCondition addIssueTypeIds(String... args) {
		for (String issueType : args) {
			issueTypeIds.add(issueType);
		}

		return this;
	}


	public IssueSearchCondition addStatusTypes(Issue.StatusType... args) {
		for (StatusType statusType : args) {
			statusTypes.add(statusType);
		}

		return this;
	}

	public IssueSearchCondition addPriorityTypes(Issue.PriorityType... args) {
		for(PriorityType priorityType : args) {
			priorityTypes.add(priorityType);
		}

		return this;
	}



	public List<String> getIssueTypeIds() {
		return issueTypeIds;
	}


	public List<Issue.StatusType> getStatusTypes() {
		return statusTypes;
	}

	public List<Issue.PriorityType> getPriorityTypes() {
		return priorityTypes;
	}

	public ParentChildType getParentChildType() {
		return parentChildType;
	}


	public IssueSearchCondition setParentChildType(ParentChildType parentChildType) {
		this.parentChildType = parentChildType;
		return this;
	}


	public String getKeyWord() {
		return keyWord;
	}


	public IssueSearchCondition setKeyWord(String keyWord) {
		this.keyWord = keyWord;
		return this;
	}


	@Override
	public String toString() {
		return "IssueSearchCondition [issueTypeIds=" + issueTypeIds + ", statusTypes=" + statusTypes
				+ ", priorityTypes=" + priorityTypes + ", parentChildType=" + parentChildType + ", keyWord=" + keyWord
				+ "]";
	}


	public enum ParentChildType {
		All, NotChild, Child, NotChildNotParent, Parent;

		public static ParentChildType getFromType(String typeName) {

			if(StringUtils.isEmpty(typeName)) {
				return null;
			}

			for (ParentChildType type : ParentChildType.values()) {
				if(typeName.equals(type.name())){
					return type;
				}
			}

			return null;
		}
	}

}
